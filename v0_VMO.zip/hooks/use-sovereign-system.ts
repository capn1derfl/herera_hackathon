import { useState, useCallback, useEffect } from 'react';

export interface SystemState {
  vmosCreated: number;
  checkpoints: number;
  proofGenerated: number;
  agentsActive: number;
  lastBoot: string | null;
  topicId: string;
  lastError: string | null;
  isBootstrapped: boolean;
}

export function useSovereignSystem() {
  const [state, setState] = useState<SystemState>({
    vmosCreated: 0,
    checkpoints: 0,
    proofGenerated: 0,
    agentsActive: 0,
    lastBoot: null,
    topicId: process.env.NEXT_PUBLIC_HEDERA_TOPIC_ID || '0.0.7564883',
    lastError: null,
    isBootstrapped: false,
  });

  const [loading, setLoading] = useState(false);

  // Boot the system from Hedera
  const boot = useCallback(async () => {
    setLoading(true);
    setState(prev => ({ ...prev, lastError: null }));
    
    try {
      const response = await fetch('/api/boot');
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Boot failed');
      }

      setState(prev => ({
        ...prev,
        vmosCreated: data.vmoCount || 0,
        checkpoints: data.checkpointCount || 0,
        lastBoot: new Date().toISOString(),
        isBootstrapped: true,
      }));
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setState(prev => ({ ...prev, lastError: errorMsg }));
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a new VMO
  const createVMO = useCallback(async (type: string, payload: any) => {
    setLoading(true);
    setState(prev => ({ ...prev, lastError: null }));

    try {
      const response = await fetch('/api/vmo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, payload }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'VMO creation failed');
      }

      setState(prev => ({
        ...prev,
        vmosCreated: prev.vmosCreated + 1,
      }));

      return data;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setState(prev => ({ ...prev, lastError: errorMsg }));
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  // Create a checkpoint and anchor to Hedera
  const createCheckpoint = useCallback(async (vmoIds: string[]) => {
    setLoading(true);
    setState(prev => ({ ...prev, lastError: null }));

    try {
      const response = await fetch('/api/checkpoint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vmoIds }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Checkpoint creation failed');
      }

      setState(prev => ({
        ...prev,
        checkpoints: prev.checkpoints + 1,
        proofGenerated: prev.proofGenerated + 1,
      }));

      return data;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setState(prev => ({ ...prev, lastError: errorMsg }));
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  // Trace a Bitcoin transaction
  const traceTransaction = useCallback(async (txid: string, depth: number = 10) => {
    setLoading(true);
    setState(prev => ({ ...prev, lastError: null }));

    try {
      const response = await fetch('/api/trace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ txid, depth }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Transaction trace failed');
      }

      return data;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setState(prev => ({ ...prev, lastError: errorMsg }));
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  // Boot on component mount
  useEffect(() => {
    boot();
  }, [boot]);

  return {
    state,
    loading,
    boot,
    createVMO,
    createCheckpoint,
    traceTransaction,
  };
}
