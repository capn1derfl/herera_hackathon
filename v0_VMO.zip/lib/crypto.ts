/**
 * Core Cryptographic Library for Sovereign Ecosystem
 * 
 * Real cryptography implementation:
 * - Ed25519 signatures via @noble/ed25519
 * - SHA-256 hashing via Web Crypto API
 * - RFC 8785 JSON Canonicalization Scheme (JCS)
 */

import * as ed from '@noble/ed25519';
import { sha512 } from '@noble/hashes/sha512';

// Configure ed25519 to use sha512
ed.etc.sha512Sync = (...m) => sha512(ed.etc.concatBytes(...m));

/**
 * RFC 8785 JSON Canonicalization Scheme (JCS)
 * Produces deterministic JSON serialization for hashing
 */
export function canonicalize(obj: unknown): string {
  if (obj === null || typeof obj !== 'object') {
    return JSON.stringify(obj);
  }

  if (Array.isArray(obj)) {
    return '[' + obj.map(canonicalize).join(',') + ']';
  }

  // Sort object keys lexicographically
  const sortedKeys = Object.keys(obj).sort();
  const pairs = sortedKeys
    .filter(key => (obj as Record<string, unknown>)[key] !== undefined)
    .map(key => {
      const value = (obj as Record<string, unknown>)[key];
      return JSON.stringify(key) + ':' + canonicalize(value);
    });
  
  return '{' + pairs.join(',') + '}';
}

/**
 * SHA-256 hash using Web Crypto API
 */
export async function sha256(data: string | Uint8Array): Promise<string> {
  const encoder = new TextEncoder();
  const dataBuffer = typeof data === 'string' ? encoder.encode(data) : data;
  const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Synchronous SHA-256 for server-side use
 */
export function sha256Sync(data: string | Uint8Array): string {
  // Use Node.js crypto for server-side
  const { createHash } = require('crypto');
  const dataStr = typeof data === 'string' ? data : Buffer.from(data).toString();
  return createHash('sha256').update(dataStr).digest('hex');
}

/**
 * Generate content hash with algorithm prefix
 */
export async function contentHash(data: unknown): Promise<string> {
  const canonical = canonicalize(data);
  const hash = await sha256(canonical);
  return `sha256:${hash}`;
}

/**
 * Synchronous content hash for server-side
 */
export function contentHashSync(data: unknown): string {
  const canonical = canonicalize(data);
  const hash = sha256Sync(canonical);
  return `sha256:${hash}`;
}

/**
 * Ed25519 Key Generation
 */
export function generateKeypair(): { privateKey: Uint8Array; publicKey: Uint8Array } {
  const privateKey = ed.utils.randomPrivateKey();
  const publicKey = ed.getPublicKey(privateKey);
  return { privateKey, publicKey };
}

/**
 * Generate keypair and return as hex strings
 */
export function generateKeypairHex(): { privateKey: string; publicKey: string } {
  const { privateKey, publicKey } = generateKeypair();
  return {
    privateKey: bytesToHex(privateKey),
    publicKey: bytesToHex(publicKey)
  };
}

/**
 * Ed25519 Sign
 */
export async function sign(message: string, privateKey: Uint8Array | string): Promise<string> {
  const encoder = new TextEncoder();
  const messageBytes = encoder.encode(message);
  const privKeyBytes = typeof privateKey === 'string' ? hexToBytes(privateKey) : privateKey;
  const signature = await ed.signAsync(messageBytes, privKeyBytes);
  return bytesToHex(signature);
}

/**
 * Synchronous Ed25519 Sign
 */
export function signSync(message: string, privateKey: Uint8Array | string): string {
  const encoder = new TextEncoder();
  const messageBytes = encoder.encode(message);
  const privKeyBytes = typeof privateKey === 'string' ? hexToBytes(privateKey) : privateKey;
  const signature = ed.sign(messageBytes, privKeyBytes);
  return bytesToHex(signature);
}

/**
 * Ed25519 Verify
 */
export async function verify(
  message: string,
  signature: string,
  publicKey: Uint8Array | string
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const messageBytes = encoder.encode(message);
    const sigBytes = hexToBytes(signature);
    const pubKeyBytes = typeof publicKey === 'string' ? hexToBytes(publicKey) : publicKey;
    return await ed.verifyAsync(sigBytes, messageBytes, pubKeyBytes);
  } catch {
    return false;
  }
}

/**
 * Synchronous Ed25519 Verify
 */
export function verifySync(
  message: string,
  signature: string,
  publicKey: Uint8Array | string
): boolean {
  try {
    const encoder = new TextEncoder();
    const messageBytes = encoder.encode(message);
    const sigBytes = hexToBytes(signature);
    const pubKeyBytes = typeof publicKey === 'string' ? hexToBytes(publicKey) : publicKey;
    return ed.verify(sigBytes, messageBytes, pubKeyBytes);
  } catch {
    return false;
  }
}

/**
 * Utility: bytes to hex string
 */
export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Utility: hex string to bytes
 */
export function hexToBytes(hex: string): Uint8Array {
  const cleanHex = hex.startsWith('0x') ? hex.slice(2) : hex;
  const bytes = new Uint8Array(cleanHex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(cleanHex.substr(i * 2, 2), 16);
  }
  return bytes;
}

/**
 * Binary Merkle Tree Implementation
 * Per whitepaper: sorted leaves, paired hashing, canonical JSON
 */
export async function merkleRoot(hashes: string[]): Promise<string> {
  if (hashes.length === 0) {
    return contentHash([]);
  }

  // Sort leaves lexicographically
  let level = [...hashes].sort();

  while (level.length > 1) {
    const next: string[] = [];
    
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left; // Duplicate last if odd
      
      // Hash the pair using canonical JSON
      const combined = await contentHash([left, right]);
      next.push(combined);
    }
    
    // Sort for determinism
    next.sort();
    level = next;
  }

  return level[0];
}

/**
 * Synchronous Merkle Root for server-side
 */
export function merkleRootSync(hashes: string[]): string {
  if (hashes.length === 0) {
    return contentHashSync([]);
  }

  let level = [...hashes].sort();

  while (level.length > 1) {
    const next: string[] = [];
    
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left;
      const combined = contentHashSync([left, right]);
      next.push(combined);
    }
    
    next.sort();
    level = next;
  }

  return level[0];
}

/**
 * Generate Merkle proof for a specific hash
 */
export function generateMerkleProof(hashes: string[], targetHash: string): {
  proof: Array<{ hash: string; position: 'left' | 'right' }>;
  root: string;
} | null {
  if (!hashes.includes(targetHash)) {
    return null;
  }

  const proof: Array<{ hash: string; position: 'left' | 'right' }> = [];
  let level = [...hashes].sort();
  let targetIndex = level.indexOf(targetHash);

  while (level.length > 1) {
    const next: string[] = [];
    
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left;
      
      // If target is in this pair, record the sibling
      if (i === targetIndex || i + 1 === targetIndex) {
        if (i === targetIndex && level[i + 1]) {
          proof.push({ hash: right, position: 'right' });
        } else if (i + 1 === targetIndex) {
          proof.push({ hash: left, position: 'left' });
        }
        targetIndex = Math.floor(i / 2);
      }
      
      const combined = contentHashSync([left, right]);
      next.push(combined);
    }
    
    next.sort();
    level = next;
  }

  return { proof, root: level[0] };
}

/**
 * Verify a Merkle proof
 */
export function verifyMerkleProof(
  targetHash: string,
  proof: Array<{ hash: string; position: 'left' | 'right' }>,
  expectedRoot: string
): boolean {
  let currentHash = targetHash;

  for (const step of proof) {
    const pair = step.position === 'left' 
      ? [step.hash, currentHash]
      : [currentHash, step.hash];
    currentHash = contentHashSync(pair);
  }

  return currentHash === expectedRoot;
}
