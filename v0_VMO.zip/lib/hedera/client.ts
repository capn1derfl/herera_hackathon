/**
 * Hedera Hashgraph Client
 * 
 * Handles:
 * - Boot from HCS topic (read all messages, reconstruct state)
 * - Anchor checkpoints to HCS
 * - Submit VMOs as consensus messages
 */

import {
  Client,
  TopicId,
  TopicMessageSubmitTransaction,
  PrivateKey,
  AccountId,
} from '@hashgraph/sdk';
import { canonicalize, contentHashSync } from '../crypto';
import type { VMO, HCSMessage, BootState, SovereignTimeline, CheckpointPayload } from '../vmo/types';
import { setVMOCounter, verifyVMOIntegrity } from '../vmo/factory';

const SCHEMA_VERSION = 'sovereign-vault-v1';

/**
 * Initialize Hedera client from environment variables
 */
export function createHederaClient(): Client | null {
  const accountId = process.env.HEDERA_ACCOUNT_ID;
  const privateKey = process.env.HEDERA_PRIVATE_KEY;
  const network = process.env.HEDERA_NETWORK || 'testnet';

  if (!accountId || !privateKey) {
    console.warn('[Hedera] Missing credentials - running in read-only mode');
    return null;
  }

  const client = network === 'mainnet' 
    ? Client.forMainnet()
    : Client.forTestnet();

  client.setOperator(AccountId.fromString(accountId), PrivateKey.fromString(privateKey));
  
  return client;
}

/**
 * Get the topic ID from environment or default
 */
export function getTopicId(): string {
  return process.env.HEDERA_TOPIC_ID || '0.0.7564883';
}

/**
 * Fetch all messages from HCS topic via mirror node
 */
export async function fetchTopicMessages(topicId: string, network: string = 'testnet'): Promise<HCSMessage[]> {
  const baseUrl = network === 'mainnet'
    ? 'https://mainnet-public.mirrornode.hedera.com'
    : 'https://testnet.mirrornode.hedera.com';

  const messages: HCSMessage[] = [];
  let nextLink: string | null = `/api/v1/topics/${topicId}/messages?limit=100&order=asc`;

  while (nextLink) {
    const url = nextLink.startsWith('http') ? nextLink : `${baseUrl}${nextLink}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      if (response.status === 404) {
        // Topic doesn't exist yet or has no messages
        return [];
      }
      throw new Error(`Mirror node error: ${response.status}`);
    }

    const data = await response.json();
    
    for (const msg of data.messages || []) {
      try {
        // Decode base64 message content
        const content = atob(msg.message);
        const parsed = JSON.parse(content) as HCSMessage;
        messages.push({
          ...parsed,
          // Add sequence info from mirror node
          _sequence: msg.sequence_number,
          _consensus_timestamp: msg.consensus_timestamp
        } as HCSMessage & { _sequence: number; _consensus_timestamp: string });
      } catch (e) {
        // Skip malformed messages
        console.warn('[Hedera] Skipping malformed message:', e);
      }
    }

    nextLink = data.links?.next || null;
  }

  return messages;
}

/**
 * Boot from Hedera - reconstruct sovereign timeline from HCS messages
 */
export async function bootFromHedera(topicId?: string): Promise<BootState> {
  const topic = topicId || getTopicId();
  const network = process.env.HEDERA_NETWORK || 'testnet';

  console.log(`[Hedera] Booting from topic ${topic} on ${network}...`);

  // Fetch all messages from HCS
  const messages = await fetchTopicMessages(topic, network);
  
  console.log(`[Hedera] Retrieved ${messages.length} messages from HCS`);

  // Initialize empty timeline
  const timeline: SovereignTimeline = {
    meta: {
      version: 'Sovereign Kernel v2.0.0',
      agent: '',
      initialized: false,
      anchor: topic,
      timestamp: new Date().toISOString(),
      topic_id: topic
    },
    recs: [],
    refs: [],
    casts: [],
    sigs: [],
    agents: [],
    capabilities: [],
    checkpoints: []
  };

  let lastSequence = 0;
  let lastCheckpoint: VMO<CheckpointPayload> | undefined;
  let integrityValid = true;
  let prevHash: string | null = null;
  let maxVmoIndex = 0;

  // Process messages in order to reconstruct state
  console.log('[v0] All messages from HCS:', JSON.stringify(messages.map(m => ({ 
    schema: m.schema, 
    vmo_id: m.vmo_id,
    type: m.vmo?.type,
    keys: Object.keys(m)
  })), null, 2));

  for (const msg of messages) {
    // Log each message for debugging
    console.log('[v0] Processing message schema:', msg.schema, 'vmo_id:', msg.vmo_id);
    
    if (msg.schema !== SCHEMA_VERSION && !msg.schema?.startsWith('sovereign-vault')) {
      console.log('[v0] Skipping message - schema mismatch:', msg.schema);
      continue; // Skip non-sovereign messages
    }

    const msgWithMeta = msg as HCSMessage & { _sequence?: number };
    if (msgWithMeta._sequence) {
      lastSequence = msgWithMeta._sequence;
    }

    // If message contains a VMO, validate and add to timeline
    if (msg.vmo) {
      const vmo = msg.vmo;
      
      // Verify integrity
      if (!verifyVMOIntegrity(vmo)) {
        console.warn(`[Hedera] VMO ${vmo.vmo_id} failed integrity check`);
        integrityValid = false;
        continue;
      }

      // Verify chain link
      if (prevHash && vmo.integrity.prev_hash !== prevHash) {
        console.warn(`[Hedera] VMO ${vmo.vmo_id} chain link broken`);
        integrityValid = false;
      }

      prevHash = vmo.integrity.content_hash;

      // Extract VMO index from ID
      const match = vmo.vmo_id.match(/:(\d+)$/);
      if (match) {
        const idx = parseInt(match[1], 10);
        if (idx > maxVmoIndex) maxVmoIndex = idx;
      }

      // Add to appropriate timeline array based on type
      switch (vmo.type) {
        case 'agent':
          timeline.agents.push(vmo as VMO<any>);
          if (!timeline.meta.agent) {
            timeline.meta.agent = (vmo.payload as any).did;
            timeline.meta.initialized = true;
          }
          break;
        case 'capability':
          timeline.capabilities.push(vmo as VMO<any>);
          break;
        case 'log':
          timeline.recs.push(vmo as VMO<any>);
          break;
        case 'checkpoint':
          timeline.checkpoints.push(vmo as VMO<CheckpointPayload>);
          lastCheckpoint = vmo as VMO<CheckpointPayload>;
          break;
        case 'refusal':
          timeline.refs.push(vmo);
          break;
        case 'cast':
          timeline.casts.push(vmo);
          break;
        case 'signature':
          timeline.sigs.push(vmo);
          break;
      }
    }
  }

  // Set VMO counter to continue from last known index
  setVMOCounter(maxVmoIndex);

  console.log(`[Hedera] Boot complete: ${timeline.agents.length} agents, ${timeline.recs.length} logs, ${timeline.checkpoints.length} checkpoints`);
  console.log(`[Hedera] Integrity: ${integrityValid ? 'VALID' : 'BROKEN'}`);

  return {
    timeline,
    last_sequence: lastSequence,
    last_checkpoint: lastCheckpoint,
    integrity_valid: integrityValid,
    message_count: messages.length
  };
}

/**
 * Submit a VMO to HCS as a consensus message
 */
export async function submitVMOToHCS(
  client: Client,
  topicId: string,
  vmo: VMO
): Promise<{ transactionId: string; sequenceNumber?: number }> {
  const message: HCSMessage = {
    schema: SCHEMA_VERSION,
    network: process.env.HEDERA_NETWORK || 'testnet',
    operator: process.env.HEDERA_ACCOUNT_ID || '',
    hash_alg: 'sha256',
    vmo_id: vmo.vmo_id,
    content_hash: vmo.integrity.content_hash,
    timestamp: new Date().toISOString(),
    vmo
  };

  const canonical = canonicalize(message);
  
  const transaction = await new TopicMessageSubmitTransaction()
    .setTopicId(TopicId.fromString(topicId))
    .setMessage(canonical)
    .execute(client);

  const receipt = await transaction.getReceipt(client);

  return {
    transactionId: transaction.transactionId.toString(),
    sequenceNumber: receipt.topicSequenceNumber?.toNumber()
  };
}

/**
 * Submit a checkpoint (Merkle root) to HCS
 */
export async function anchorCheckpoint(
  client: Client,
  topicId: string,
  checkpointVmo: VMO<CheckpointPayload>
): Promise<{ transactionId: string; sequenceNumber?: number }> {
  // Create anchor message
  const message: HCSMessage = {
    schema: 'sovereign-vault-checkpoint-v1',
    network: process.env.HEDERA_NETWORK || 'testnet',
    operator: process.env.HEDERA_ACCOUNT_ID || '',
    hash_alg: 'sha256',
    vmo_id: checkpointVmo.vmo_id,
    merkle_root: checkpointVmo.payload.merkle_root,
    timestamp: new Date().toISOString(),
    vmo: checkpointVmo
  };

  const canonical = canonicalize(message);

  const transaction = await new TopicMessageSubmitTransaction()
    .setTopicId(TopicId.fromString(topicId))
    .setMessage(canonical)
    .execute(client);

  const receipt = await transaction.getReceipt(client);

  return {
    transactionId: transaction.transactionId.toString(),
    sequenceNumber: receipt.topicSequenceNumber?.toNumber()
  };
}

/**
 * Verify that a checkpoint is anchored on Hedera
 */
export async function verifyCheckpointAnchor(
  topicId: string,
  checkpointId: string,
  expectedMerkleRoot: string
): Promise<{ verified: boolean; message?: HCSMessage; error?: string }> {
  const network = process.env.HEDERA_NETWORK || 'testnet';
  const messages = await fetchTopicMessages(topicId, network);

  for (const msg of messages) {
    if (msg.vmo_id === checkpointId || msg.merkle_root === expectedMerkleRoot) {
      if (msg.merkle_root === expectedMerkleRoot) {
        return { verified: true, message: msg };
      }
    }
  }

  return { verified: false, error: 'Checkpoint not found on Hedera' };
}
