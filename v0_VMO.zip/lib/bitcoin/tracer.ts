/**
 * URAT v0.2 Bitcoin Tracer
 * 
 * Real Bitcoin transaction tracing via mempool.space API
 * Pattern detection: mixers, peel chains, fan-outs, consolidations
 */

const MEMPOOL_API = 'https://mempool.space/api';

/**
 * Bitcoin Transaction from mempool.space
 */
export interface BitcoinTransaction {
  txid: string;
  version: number;
  locktime: number;
  size: number;
  weight: number;
  fee: number;
  status: {
    confirmed: boolean;
    block_height?: number;
    block_hash?: string;
    block_time?: number;
  };
  vin: Array<{
    txid: string;
    vout: number;
    prevout: {
      scriptpubkey: string;
      scriptpubkey_address?: string;
      scriptpubkey_asm: string;
      scriptpubkey_type: string;
      value: number;
    };
    scriptsig: string;
    scriptsig_asm: string;
    witness?: string[];
    is_coinbase: boolean;
    sequence: number;
  }>;
  vout: Array<{
    scriptpubkey: string;
    scriptpubkey_address?: string;
    scriptpubkey_asm: string;
    scriptpubkey_type: string;
    value: number;
  }>;
}

/**
 * Address information
 */
export interface AddressInfo {
  address: string;
  chain_stats: {
    funded_txo_count: number;
    funded_txo_sum: number;
    spent_txo_count: number;
    spent_txo_sum: number;
    tx_count: number;
  };
  mempool_stats: {
    funded_txo_count: number;
    funded_txo_sum: number;
    spent_txo_count: number;
    spent_txo_sum: number;
    tx_count: number;
  };
}

/**
 * Trace hop in the provenance chain
 */
export interface TraceHop {
  hop: number;
  txid: string;
  timestamp?: number;
  block_height?: number;
  inputs: Array<{
    address?: string;
    value: number;
    txid: string;
    vout: number;
  }>;
  outputs: Array<{
    address?: string;
    value: number;
    index: number;
  }>;
  fee: number;
  patterns: string[];
  risk_score: number;
}

/**
 * Complete trace result
 */
export interface TraceResult {
  start_txid: string;
  direction: 'forward' | 'backward';
  hops: TraceHop[];
  total_hops: number;
  patterns_detected: string[];
  risk_assessment: {
    score: number;
    level: 'low' | 'medium' | 'high' | 'critical';
    factors: string[];
  };
  addresses_involved: string[];
  total_value_traced: number;
  trace_timestamp: string;
}

/**
 * Fetch transaction from mempool.space
 */
export async function fetchTransaction(txid: string): Promise<BitcoinTransaction> {
  const response = await fetch(`${MEMPOOL_API}/tx/${txid}`);
  if (!response.ok) {
    throw new Error(`Transaction not found: ${txid}`);
  }
  return response.json();
}

/**
 * Fetch address info
 */
export async function fetchAddressInfo(address: string): Promise<AddressInfo> {
  const response = await fetch(`${MEMPOOL_API}/address/${address}`);
  if (!response.ok) {
    throw new Error(`Address not found: ${address}`);
  }
  return response.json();
}

/**
 * Fetch transactions for an address
 */
export async function fetchAddressTransactions(address: string): Promise<BitcoinTransaction[]> {
  const response = await fetch(`${MEMPOOL_API}/address/${address}/txs`);
  if (!response.ok) {
    throw new Error(`Failed to fetch address transactions: ${address}`);
  }
  return response.json();
}

/**
 * Detect patterns in a transaction
 */
export function detectPatterns(tx: BitcoinTransaction): string[] {
  const patterns: string[] = [];
  
  const inputCount = tx.vin.length;
  const outputCount = tx.vout.length;
  const inputAddresses = new Set(tx.vin.map(v => v.prevout?.scriptpubkey_address).filter(Boolean));
  const outputAddresses = new Set(tx.vout.map(v => v.scriptpubkey_address).filter(Boolean));
  
  // Fan-out: 1-2 inputs, many outputs (possible distribution)
  if (inputCount <= 2 && outputCount >= 5) {
    patterns.push('fan-out');
  }
  
  // Consolidation: many inputs, 1-2 outputs
  if (inputCount >= 5 && outputCount <= 2) {
    patterns.push('consolidation');
  }
  
  // Peel chain: 2 outputs where one is much smaller (change)
  if (outputCount === 2) {
    const values = tx.vout.map(v => v.value).sort((a, b) => b - a);
    const ratio = values[1] / values[0];
    if (ratio < 0.1) {
      patterns.push('peel-chain');
    }
  }
  
  // Self-transfer: same address in input and output
  const overlap = [...inputAddresses].filter(a => outputAddresses.has(a));
  if (overlap.length > 0) {
    patterns.push('self-transfer');
  }
  
  // Coinjoin indicators: many inputs AND many outputs with similar values
  if (inputCount >= 3 && outputCount >= 3) {
    const outputValues = tx.vout.map(v => v.value);
    const uniqueValues = new Set(outputValues);
    // If many outputs have the same value, possible coinjoin
    if (uniqueValues.size < outputValues.length * 0.5) {
      patterns.push('possible-coinjoin');
    }
  }
  
  // Round number outputs (possible exchange withdrawal)
  const roundOutputs = tx.vout.filter(v => {
    const btc = v.value / 100000000;
    return btc === Math.round(btc * 10) / 10; // Round to 0.1 BTC
  });
  if (roundOutputs.length > 0 && roundOutputs.length < outputCount) {
    patterns.push('round-amount');
  }
  
  // High fee (possible RBF or urgency)
  const totalInput = tx.vin.reduce((sum, v) => sum + (v.prevout?.value || 0), 0);
  const totalOutput = tx.vout.reduce((sum, v) => sum + v.value, 0);
  const feeRate = tx.fee / tx.weight * 4; // sat/vbyte
  if (feeRate > 100) {
    patterns.push('high-fee');
  }
  
  return patterns;
}

/**
 * Calculate risk score based on patterns
 */
export function calculateRiskScore(patterns: string[]): number {
  const scores: Record<string, number> = {
    'fan-out': 15,
    'consolidation': 10,
    'peel-chain': 20,
    'self-transfer': 5,
    'possible-coinjoin': 40,
    'round-amount': 10,
    'high-fee': 15
  };
  
  let score = 0;
  for (const pattern of patterns) {
    score += scores[pattern] || 0;
  }
  
  return Math.min(100, score);
}

/**
 * Get risk level from score
 */
export function getRiskLevel(score: number): 'low' | 'medium' | 'high' | 'critical' {
  if (score < 20) return 'low';
  if (score < 40) return 'medium';
  if (score < 70) return 'high';
  return 'critical';
}

/**
 * Trace transaction chain forward (follow outputs being spent)
 */
export async function traceForward(
  startTxid: string,
  maxHops: number = 10,
  outputIndex?: number
): Promise<TraceResult> {
  const hops: TraceHop[] = [];
  const addressesInvolved = new Set<string>();
  const allPatterns = new Set<string>();
  let currentTxid = startTxid;
  let totalValueTraced = 0;
  let targetOutputIndex = outputIndex;

  for (let hop = 0; hop < maxHops; hop++) {
    try {
      const tx = await fetchTransaction(currentTxid);
      
      // Collect input addresses
      for (const input of tx.vin) {
        if (input.prevout?.scriptpubkey_address) {
          addressesInvolved.add(input.prevout.scriptpubkey_address);
        }
      }
      
      // Collect output addresses
      for (const output of tx.vout) {
        if (output.scriptpubkey_address) {
          addressesInvolved.add(output.scriptpubkey_address);
        }
      }
      
      const patterns = detectPatterns(tx);
      patterns.forEach(p => allPatterns.add(p));
      
      const traceHop: TraceHop = {
        hop: hop + 1,
        txid: tx.txid,
        timestamp: tx.status.block_time,
        block_height: tx.status.block_height,
        inputs: tx.vin.map(v => ({
          address: v.prevout?.scriptpubkey_address,
          value: v.prevout?.value || 0,
          txid: v.txid,
          vout: v.vout
        })),
        outputs: tx.vout.map((v, i) => ({
          address: v.scriptpubkey_address,
          value: v.value,
          index: i
        })),
        fee: tx.fee,
        patterns,
        risk_score: calculateRiskScore(patterns)
      };
      
      hops.push(traceHop);
      totalValueTraced += tx.vout.reduce((sum, v) => sum + v.value, 0);
      
      // Find next transaction by checking if any output was spent
      // For now, we'll trace the largest output
      if (targetOutputIndex !== undefined) {
        // Specific output requested
        const targetOutput = tx.vout[targetOutputIndex];
        if (targetOutput?.scriptpubkey_address) {
          const addressTxs = await fetchAddressTransactions(targetOutput.scriptpubkey_address);
          const spendingTx = addressTxs.find(t => 
            t.vin.some(v => v.txid === currentTxid && v.vout === targetOutputIndex)
          );
          if (spendingTx) {
            currentTxid = spendingTx.txid;
            targetOutputIndex = undefined;
            continue;
          }
        }
        break; // Output not spent yet
      } else {
        // Trace largest non-change output
        const sortedOutputs = [...tx.vout]
          .map((v, i) => ({ ...v, index: i }))
          .filter(v => v.scriptpubkey_address)
          .sort((a, b) => b.value - a.value);
        
        let foundNext = false;
        for (const output of sortedOutputs) {
          if (output.scriptpubkey_address) {
            try {
              const addressTxs = await fetchAddressTransactions(output.scriptpubkey_address);
              const spendingTx = addressTxs.find(t => 
                t.vin.some(v => v.txid === currentTxid && v.vout === output.index)
              );
              if (spendingTx) {
                currentTxid = spendingTx.txid;
                foundNext = true;
                break;
              }
            } catch {
              continue;
            }
          }
        }
        
        if (!foundNext) break;
      }
      
      // Rate limiting - be nice to mempool.space
      await new Promise(resolve => setTimeout(resolve, 200));
      
    } catch (error) {
      console.error(`[URAT] Trace error at hop ${hop + 1}:`, error);
      break;
    }
  }
  
  const allPatternsArray = Array.from(allPatterns);
  const totalRisk = hops.reduce((sum, h) => sum + h.risk_score, 0) / Math.max(hops.length, 1);
  
  return {
    start_txid: startTxid,
    direction: 'forward',
    hops,
    total_hops: hops.length,
    patterns_detected: allPatternsArray,
    risk_assessment: {
      score: Math.round(totalRisk),
      level: getRiskLevel(totalRisk),
      factors: allPatternsArray
    },
    addresses_involved: Array.from(addressesInvolved),
    total_value_traced: totalValueTraced,
    trace_timestamp: new Date().toISOString()
  };
}

/**
 * Trace transaction chain backward (follow inputs)
 */
export async function traceBackward(
  startTxid: string,
  maxHops: number = 10,
  inputIndex?: number
): Promise<TraceResult> {
  const hops: TraceHop[] = [];
  const addressesInvolved = new Set<string>();
  const allPatterns = new Set<string>();
  let currentTxid = startTxid;
  let totalValueTraced = 0;

  for (let hop = 0; hop < maxHops; hop++) {
    try {
      const tx = await fetchTransaction(currentTxid);
      
      // Collect addresses
      for (const input of tx.vin) {
        if (input.prevout?.scriptpubkey_address) {
          addressesInvolved.add(input.prevout.scriptpubkey_address);
        }
      }
      for (const output of tx.vout) {
        if (output.scriptpubkey_address) {
          addressesInvolved.add(output.scriptpubkey_address);
        }
      }
      
      const patterns = detectPatterns(tx);
      patterns.forEach(p => allPatterns.add(p));
      
      const traceHop: TraceHop = {
        hop: hop + 1,
        txid: tx.txid,
        timestamp: tx.status.block_time,
        block_height: tx.status.block_height,
        inputs: tx.vin.map(v => ({
          address: v.prevout?.scriptpubkey_address,
          value: v.prevout?.value || 0,
          txid: v.txid,
          vout: v.vout
        })),
        outputs: tx.vout.map((v, i) => ({
          address: v.scriptpubkey_address,
          value: v.value,
          index: i
        })),
        fee: tx.fee,
        patterns,
        risk_score: calculateRiskScore(patterns)
      };
      
      hops.push(traceHop);
      totalValueTraced += tx.vin.reduce((sum, v) => sum + (v.prevout?.value || 0), 0);
      
      // Move to previous transaction (largest input)
      if (tx.vin[0]?.is_coinbase) {
        // Reached coinbase - end of chain
        break;
      }
      
      const targetIdx = inputIndex !== undefined && hop === 0 ? inputIndex : 0;
      const largestInput = tx.vin[targetIdx] || tx.vin[0];
      
      if (largestInput?.txid) {
        currentTxid = largestInput.txid;
      } else {
        break;
      }
      
      // Rate limiting
      await new Promise(resolve => setTimeout(resolve, 200));
      
    } catch (error) {
      console.error(`[URAT] Backward trace error at hop ${hop + 1}:`, error);
      break;
    }
  }
  
  const allPatternsArray = Array.from(allPatterns);
  const totalRisk = hops.reduce((sum, h) => sum + h.risk_score, 0) / Math.max(hops.length, 1);
  
  return {
    start_txid: startTxid,
    direction: 'backward',
    hops,
    total_hops: hops.length,
    patterns_detected: allPatternsArray,
    risk_assessment: {
      score: Math.round(totalRisk),
      level: getRiskLevel(totalRisk),
      factors: allPatternsArray
    },
    addresses_involved: Array.from(addressesInvolved),
    total_value_traced: totalValueTraced,
    trace_timestamp: new Date().toISOString()
  };
}

/**
 * Generate URAT attestation packet for a trace
 */
export function generateAttestationPacket(trace: TraceResult, agentDid: string): {
  version: string;
  attestation_id: string;
  agent: string;
  timestamp: string;
  subject: {
    type: string;
    txid: string;
    direction: string;
  };
  findings: {
    hops_traced: number;
    patterns: string[];
    risk_level: string;
    risk_score: number;
    addresses_count: number;
    value_traced_satoshis: number;
  };
  evidence: TraceHop[];
  signature_pending: boolean;
} {
  return {
    version: 'URAT-v0.2',
    attestation_id: `urat:${trace.start_txid.slice(0, 8)}:${Date.now().toString(36)}`,
    agent: agentDid,
    timestamp: new Date().toISOString(),
    subject: {
      type: 'bitcoin-transaction',
      txid: trace.start_txid,
      direction: trace.direction
    },
    findings: {
      hops_traced: trace.total_hops,
      patterns: trace.patterns_detected,
      risk_level: trace.risk_assessment.level,
      risk_score: trace.risk_assessment.score,
      addresses_count: trace.addresses_involved.length,
      value_traced_satoshis: trace.total_value_traced
    },
    evidence: trace.hops,
    signature_pending: true
  };
}
