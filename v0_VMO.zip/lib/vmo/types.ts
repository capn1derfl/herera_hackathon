/**
 * Verifiable Memory Object (VMO) Type Definitions
 * Per whitepaper: "Verifiable Memory Objects: A Complete Architecture for Data Integrity and Provenance"
 */

export type VMOType = 
  | 'agent'
  | 'capability'
  | 'log'
  | 'checkpoint'
  | 'attestation'
  | 'refusal'
  | 'cast'
  | 'signature';

export type VisibilityScope = 'private' | 'shared' | 'public';

export interface VMOProvenance {
  agent_did: string;
  capability_id: string | null;
  timestamp: string;
}

export interface VMOVisibility {
  scope: VisibilityScope;
  tags: string[];
}

export interface VMOLineage {
  supersedes: string[];
  conflicts_with: string[];
}

export interface VMOIntegrity {
  content_hash: string;
  prev_hash: string | null;
  signature?: string;
}

/**
 * Base VMO Structure
 */
export interface VMO<T = unknown> {
  vmo_id: string;
  type: VMOType;
  payload: T;
  provenance: VMOProvenance;
  visibility: VMOVisibility;
  lineage: VMOLineage;
  integrity: VMOIntegrity;
}

/**
 * Agent VMO Payload
 */
export interface AgentPayload {
  did: string;
  public_key: string;
  metadata: {
    name: string;
    description?: string;
    created?: string;
  };
}

/**
 * Capability VMO Payload
 */
export interface CapabilityPayload {
  capability_id: string;
  issued_by: string;
  issued_to: string;
  permissions: string[];
  resources: string[];
  constraints: {
    expires?: string;
    max_uses?: number;
    conditions?: string[];
  };
}

/**
 * Log VMO Payload
 */
export interface LogPayload {
  action: string;
  target_vmo?: string;
  details: string;
  data?: Record<string, unknown>;
}

/**
 * Checkpoint VMO Payload
 */
export interface CheckpointPayload {
  checkpoint_id: string;
  merkle_root: string;
  vmo_count: number;
  vmo_ids: string[];
  anchor?: {
    network: string;
    topic_id: string;
    sequence_number?: number;
    timestamp?: string;
    transaction_id?: string;
  };
}

/**
 * Attestation VMO Payload (for URAT)
 */
export interface AttestationPayload {
  attestation_id: string;
  subject: string;
  claims: Record<string, unknown>;
  evidence: {
    type: string;
    source: string;
    data: unknown;
  }[];
  confidence: number;
}

/**
 * Sovereign Timeline Structure
 */
export interface SovereignTimeline {
  meta: {
    version: string;
    agent: string;
    initialized: boolean;
    anchor: string;
    timestamp: string;
    topic_id?: string;
  };
  recs: VMO<LogPayload>[];
  refs: VMO[];
  casts: VMO[];
  sigs: VMO[];
  agents: VMO<AgentPayload>[];
  capabilities: VMO<CapabilityPayload>[];
  checkpoints: VMO<CheckpointPayload>[];
}

/**
 * Hedera HCS Message Format
 */
export interface HCSMessage {
  schema: string;
  network: string;
  operator: string;
  hash_alg: string;
  vmo_id: string;
  merkle_root?: string;
  content_hash?: string;
  timestamp: string;
  vmo?: VMO;
}

/**
 * Boot State from Hedera
 */
export interface BootState {
  timeline: SovereignTimeline;
  last_sequence: number;
  last_checkpoint?: VMO<CheckpointPayload>;
  integrity_valid: boolean;
  message_count: number;
}
