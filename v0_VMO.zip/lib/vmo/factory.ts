/**
 * VMO Factory - Creates Verifiable Memory Objects with proper integrity
 */

import { contentHashSync, signSync, generateKeypairHex } from '../crypto';
import type {
  VMO,
  VMOType,
  VMOProvenance,
  VMOVisibility,
  AgentPayload,
  CapabilityPayload,
  LogPayload,
  CheckpointPayload,
  AttestationPayload
} from './types';

let vmoCounter = 0;

/**
 * Generate a new VMO ID
 */
export function generateVMOId(type: VMOType): string {
  vmoCounter++;
  const padded = String(vmoCounter).padStart(6, '0');
  return `vmo:${type}:${padded}`;
}

/**
 * Reset counter (for testing or boot)
 */
export function resetVMOCounter(value: number = 0): void {
  vmoCounter = value;
}

/**
 * Set counter to specific value (for boot from Hedera)
 */
export function setVMOCounter(value: number): void {
  vmoCounter = value;
}

/**
 * Get current counter value
 */
export function getVMOCounter(): number {
  return vmoCounter;
}

/**
 * Create a VMO with full integrity chain
 */
export function createVMO<T>(
  type: VMOType,
  payload: T,
  provenance: Omit<VMOProvenance, 'timestamp'>,
  options: {
    visibility?: Partial<VMOVisibility>;
    prevHash?: string | null;
    supersedes?: string[];
    privateKey?: string;
    vmoId?: string;
  } = {}
): VMO<T> {
  const vmo_id = options.vmoId || generateVMOId(type);
  const timestamp = new Date().toISOString();

  // Compute content hash from canonical JSON of type, payload, and provenance
  const hashInput = {
    type,
    payload,
    provenance: {
      ...provenance,
      timestamp
    }
  };
  const content_hash = contentHashSync(hashInput);

  // Optional signature
  let signature: string | undefined;
  if (options.privateKey) {
    signature = signSync(content_hash, options.privateKey);
  }

  const vmo: VMO<T> = {
    vmo_id,
    type,
    payload,
    provenance: {
      ...provenance,
      timestamp
    },
    visibility: {
      scope: options.visibility?.scope || 'shared',
      tags: options.visibility?.tags || [type]
    },
    lineage: {
      supersedes: options.supersedes || [],
      conflicts_with: []
    },
    integrity: {
      content_hash,
      prev_hash: options.prevHash || null,
      signature
    }
  };

  return vmo;
}

/**
 * Create an Agent VMO
 */
export function createAgentVMO(
  name: string,
  did: string,
  publicKey: string,
  options: {
    description?: string;
    prevHash?: string | null;
    privateKey?: string;
  } = {}
): VMO<AgentPayload> {
  const payload: AgentPayload = {
    did,
    public_key: publicKey,
    metadata: {
      name,
      description: options.description,
      created: new Date().toISOString()
    }
  };

  return createVMO('agent', payload, {
    agent_did: did,
    capability_id: null
  }, {
    prevHash: options.prevHash,
    privateKey: options.privateKey,
    visibility: { scope: 'public', tags: ['agent', 'genesis'] }
  });
}

/**
 * Create a Capability VMO
 */
export function createCapabilityVMO(
  issuedBy: string,
  issuedTo: string,
  permissions: string[],
  resources: string[],
  options: {
    expires?: string;
    maxUses?: number;
    conditions?: string[];
    prevHash?: string | null;
    privateKey?: string;
  } = {}
): VMO<CapabilityPayload> {
  const capability_id = `cap:${contentHashSync({ issuedBy, issuedTo, permissions, ts: Date.now() }).slice(7, 15)}`;
  
  const payload: CapabilityPayload = {
    capability_id,
    issued_by: issuedBy,
    issued_to: issuedTo,
    permissions,
    resources,
    constraints: {
      expires: options.expires,
      max_uses: options.maxUses,
      conditions: options.conditions
    }
  };

  return createVMO('capability', payload, {
    agent_did: issuedBy,
    capability_id: null
  }, {
    prevHash: options.prevHash,
    privateKey: options.privateKey,
    visibility: { scope: 'shared', tags: ['capability'] }
  });
}

/**
 * Create a Log VMO
 */
export function createLogVMO(
  agentDid: string,
  action: string,
  details: string,
  options: {
    targetVmo?: string;
    data?: Record<string, unknown>;
    capabilityId?: string;
    prevHash?: string | null;
    privateKey?: string;
  } = {}
): VMO<LogPayload> {
  const payload: LogPayload = {
    action,
    target_vmo: options.targetVmo,
    details,
    data: options.data
  };

  return createVMO('log', payload, {
    agent_did: agentDid,
    capability_id: options.capabilityId || null
  }, {
    prevHash: options.prevHash,
    privateKey: options.privateKey,
    visibility: { scope: 'shared', tags: ['log', action] }
  });
}

/**
 * Create a Checkpoint VMO with Merkle root
 */
export function createCheckpointVMO(
  agentDid: string,
  merkleRoot: string,
  vmoIds: string[],
  options: {
    anchor?: {
      network: string;
      topic_id: string;
      sequence_number?: number;
      timestamp?: string;
      transaction_id?: string;
    };
    prevHash?: string | null;
    privateKey?: string;
  } = {}
): VMO<CheckpointPayload> {
  const checkpoint_id = `chk:${contentHashSync({ merkleRoot, ts: Date.now() }).slice(7, 15)}`;

  const payload: CheckpointPayload = {
    checkpoint_id,
    merkle_root: merkleRoot,
    vmo_count: vmoIds.length,
    vmo_ids: vmoIds,
    anchor: options.anchor
  };

  return createVMO('checkpoint', payload, {
    agent_did: agentDid,
    capability_id: null
  }, {
    prevHash: options.prevHash,
    privateKey: options.privateKey,
    visibility: { scope: 'public', tags: ['checkpoint', 'anchor'] }
  });
}

/**
 * Create an Attestation VMO (for URAT)
 */
export function createAttestationVMO(
  agentDid: string,
  subject: string,
  claims: Record<string, unknown>,
  evidence: { type: string; source: string; data: unknown }[],
  confidence: number,
  options: {
    prevHash?: string | null;
    privateKey?: string;
  } = {}
): VMO<AttestationPayload> {
  const attestation_id = `att:${contentHashSync({ subject, claims, ts: Date.now() }).slice(7, 15)}`;

  const payload: AttestationPayload = {
    attestation_id,
    subject,
    claims,
    evidence,
    confidence
  };

  return createVMO('attestation', payload, {
    agent_did: agentDid,
    capability_id: null
  }, {
    prevHash: options.prevHash,
    privateKey: options.privateKey,
    visibility: { scope: 'shared', tags: ['attestation', 'urat'] }
  });
}

/**
 * Verify VMO integrity
 */
export function verifyVMOIntegrity(vmo: VMO): boolean {
  const hashInput = {
    type: vmo.type,
    payload: vmo.payload,
    provenance: vmo.provenance
  };
  const computed = contentHashSync(hashInput);
  return computed === vmo.integrity.content_hash;
}

/**
 * Verify chain integrity between two VMOs
 */
export function verifyChainLink(current: VMO, previous: VMO): boolean {
  return current.integrity.prev_hash === previous.integrity.content_hash;
}

/**
 * Generate a new agent with keypair
 */
export function generateAgent(name: string, options: { description?: string } = {}): {
  agent: VMO<AgentPayload>;
  privateKey: string;
  publicKey: string;
  did: string;
} {
  const { privateKey, publicKey } = generateKeypairHex();
  const did = `did:zpid:local:${publicKey.slice(0, 16)}`;
  
  const agent = createAgentVMO(name, did, `ed25519:${publicKey}`, {
    description: options.description,
    privateKey
  });

  return { agent, privateKey, publicKey, did };
}
