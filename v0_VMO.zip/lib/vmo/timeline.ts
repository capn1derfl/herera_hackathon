/**
 * Sovereign Timeline - In-memory state management
 * 
 * This is the runtime state that boots from Hedera and accumulates VMOs.
 * On each boot, the system reads all HCS messages and reconstructs this state.
 */

import { merkleRootSync, verifySync } from '../crypto';
import type { 
  VMO, 
  SovereignTimeline, 
  AgentPayload, 
  CapabilityPayload, 
  LogPayload,
  CheckpointPayload
} from './types';
import { 
  createLogVMO, 
  createCheckpointVMO, 
  verifyVMOIntegrity,
  verifyChainLink 
} from './factory';

// Runtime state - reconstructed from Hedera on boot
let timeline: SovereignTimeline | null = null;
let lastHash: string | null = null;

/**
 * Initialize timeline (called after boot from Hedera)
 */
export function initializeTimeline(bootedTimeline: SovereignTimeline): void {
  timeline = bootedTimeline;
  
  // Find the last hash in the chain
  const allVmos = getAllVMOs();
  if (allVmos.length > 0) {
    lastHash = allVmos[allVmos.length - 1].integrity.content_hash;
  }
}

/**
 * Create fresh timeline (for new systems with no Hedera history)
 */
export function createFreshTimeline(agentDid: string, topicId: string): SovereignTimeline {
  timeline = {
    meta: {
      version: 'Sovereign Kernel v2.0.0',
      agent: agentDid,
      initialized: true,
      anchor: topicId,
      timestamp: new Date().toISOString(),
      topic_id: topicId
    },
    recs: [],
    refs: [],
    casts: [],
    sigs: [],
    agents: [],
    capabilities: [],
    checkpoints: []
  };
  lastHash = null;
  return timeline;
}

/**
 * Get current timeline state
 */
export function getTimeline(): SovereignTimeline | null {
  return timeline;
}

/**
 * Get the last hash in the chain (for linking new VMOs)
 */
export function getLastHash(): string | null {
  return lastHash;
}

/**
 * Add a VMO to the timeline
 */
export function addVMO(vmo: VMO): void {
  if (!timeline) {
    throw new Error('Timeline not initialized - boot from Hedera first');
  }

  // Update chain
  lastHash = vmo.integrity.content_hash;

  // Add to appropriate array
  switch (vmo.type) {
    case 'agent':
      timeline.agents.push(vmo as VMO<AgentPayload>);
      break;
    case 'capability':
      timeline.capabilities.push(vmo as VMO<CapabilityPayload>);
      break;
    case 'log':
      timeline.recs.push(vmo as VMO<LogPayload>);
      break;
    case 'checkpoint':
      timeline.checkpoints.push(vmo as VMO<CheckpointPayload>);
      break;
    case 'refusal':
      timeline.refs.push(vmo);
      break;
    case 'cast':
      timeline.casts.push(vmo);
      break;
    case 'signature':
      timeline.sigs.push(vmo);
      break;
  }
}

/**
 * Get all VMOs in chronological order
 */
export function getAllVMOs(): VMO[] {
  if (!timeline) return [];

  // Combine all VMO arrays and sort by timestamp
  const all = [
    ...timeline.agents,
    ...timeline.capabilities,
    ...timeline.recs,
    ...timeline.checkpoints,
    ...timeline.refs,
    ...timeline.casts,
    ...timeline.sigs
  ];

  return all.sort((a, b) => 
    new Date(a.provenance.timestamp).getTime() - new Date(b.provenance.timestamp).getTime()
  );
}

/**
 * Get VMO by ID
 */
export function getVMOById(vmoId: string): VMO | undefined {
  const all = getAllVMOs();
  return all.find(v => v.vmo_id === vmoId);
}

/**
 * Get all content hashes for Merkle tree
 */
export function getAllContentHashes(): string[] {
  return getAllVMOs().map(v => v.integrity.content_hash);
}

/**
 * Compute current Merkle root of all VMOs
 */
export function computeMerkleRoot(): string {
  const hashes = getAllContentHashes();
  return merkleRootSync(hashes);
}

/**
 * Create a checkpoint of current state
 */
export function createCheckpoint(agentDid: string, privateKey?: string): VMO<CheckpointPayload> {
  const allVmos = getAllVMOs();
  const vmoIds = allVmos.map(v => v.vmo_id);
  const merkleRoot = computeMerkleRoot();

  const checkpoint = createCheckpointVMO(
    agentDid,
    merkleRoot,
    vmoIds,
    {
      prevHash: lastHash,
      privateKey
    }
  );

  addVMO(checkpoint);
  return checkpoint;
}

/**
 * Log an action to the timeline
 */
export function logAction(
  agentDid: string,
  action: string,
  details: string,
  data?: Record<string, unknown>,
  privateKey?: string
): VMO<LogPayload> {
  const log = createLogVMO(agentDid, action, details, {
    data,
    prevHash: lastHash,
    privateKey
  });

  addVMO(log);
  return log;
}

/**
 * Verify entire chain integrity
 */
export function verifyChainIntegrity(): { 
  valid: boolean; 
  errors: string[];
  verified: number;
} {
  const errors: string[] = [];
  const allVmos = getAllVMOs();

  if (allVmos.length === 0) {
    return { valid: true, errors: [], verified: 0 };
  }

  let prevHash: string | null = null;

  for (let i = 0; i < allVmos.length; i++) {
    const vmo = allVmos[i];

    // Verify content hash
    if (!verifyVMOIntegrity(vmo)) {
      errors.push(`VMO ${vmo.vmo_id}: content hash mismatch`);
    }

    // Verify chain link (skip first VMO)
    if (i > 0 && vmo.integrity.prev_hash !== prevHash) {
      errors.push(`VMO ${vmo.vmo_id}: chain link broken (expected ${prevHash}, got ${vmo.integrity.prev_hash})`);
    }

    prevHash = vmo.integrity.content_hash;
  }

  return {
    valid: errors.length === 0,
    errors,
    verified: allVmos.length
  };
}

/**
 * Get timeline statistics
 */
export function getTimelineStats(): {
  totalVmos: number;
  agents: number;
  capabilities: number;
  logs: number;
  checkpoints: number;
  lastCheckpoint?: string;
  merkleRoot: string;
  initialized: boolean;
} {
  if (!timeline) {
    return {
      totalVmos: 0,
      agents: 0,
      capabilities: 0,
      logs: 0,
      checkpoints: 0,
      merkleRoot: '',
      initialized: false
    };
  }

  return {
    totalVmos: getAllVMOs().length,
    agents: timeline.agents.length,
    capabilities: timeline.capabilities.length,
    logs: timeline.recs.length,
    checkpoints: timeline.checkpoints.length,
    lastCheckpoint: timeline.checkpoints[timeline.checkpoints.length - 1]?.vmo_id,
    merkleRoot: computeMerkleRoot(),
    initialized: timeline.meta.initialized
  };
}

/**
 * Find agent by DID
 */
export function findAgentByDid(did: string): VMO<AgentPayload> | undefined {
  if (!timeline) return undefined;
  return timeline.agents.find(a => a.payload.did === did);
}

/**
 * Find capabilities for an agent
 */
export function findCapabilitiesForAgent(did: string): VMO<CapabilityPayload>[] {
  if (!timeline) return [];
  return timeline.capabilities.filter(c => c.payload.issued_to === did);
}

/**
 * Verify agent signature on a VMO
 */
export function verifyVMOSignature(vmo: VMO): boolean {
  if (!vmo.integrity.signature) return false;
  
  const agent = findAgentByDid(vmo.provenance.agent_did);
  if (!agent) return false;

  const publicKey = agent.payload.public_key.replace('ed25519:', '');
  return verifySync(vmo.integrity.content_hash, vmo.integrity.signature, publicKey);
}
