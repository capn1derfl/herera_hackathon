export type TabId = "overview" | "urat" | "vault" | "hhtps" | "workflows"

export interface SystemState {
  vmosCreated: number
  checkpoints: number
  proofGenerated: number
  agentsActive: number
  lastBoot: string | null
  topicId: string
  lastError: string | null
  isBootstrapped: boolean
}

export interface SovereignSystem {
  state: SystemState
  loading: boolean
  boot: () => Promise<void>
  createVMO: (type: string, payload: any) => Promise<any>
  createCheckpoint: (vmoIds: string[]) => Promise<any>
  traceTransaction: (txid: string, depth: number) => Promise<any>
}
