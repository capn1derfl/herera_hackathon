"use client"

import { useState, useEffect } from "react"
import { useSovereignSystem } from "@/hooks/use-sovereign-system"
import { OverviewPanel } from "@/components/panels/overview-panel"
import { URATPanel } from "@/components/panels/urat-panel"
import { VaultPanel } from "@/components/panels/vault-panel"
import { HHTTPSPanel } from "@/components/panels/hhtps-panel"
import { WorkflowsPanel } from "@/components/panels/workflows-panel"
import { OutputPanel } from "@/components/output-panel"

type TabId = "overview" | "urat" | "vault" | "hhtps" | "workflows"

const tabs: { id: TabId; name: string; icon: string }[] = [
  { id: "overview", name: "Overview", icon: "\u25C8" },
  { id: "urat", name: "URAT Bitcoin Tracer", icon: "\u20BF" },
  { id: "vault", name: "Sovereign Vault", icon: "\u2B22" },
  { id: "hhtps", name: "hhtps:// Protocol", icon: "\u26A1" },
  { id: "workflows", name: "Integration Workflows", icon: "\u2299" },
]

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabId>("overview")
  const [output, setOutput] = useState("")
  const system = useSovereignSystem()

  return (
    <div className="relative min-h-screen">
      {/* Grid Background */}
      <div className="grid-bg" />
      
      {/* Content */}
      <div className="relative z-10 p-8">
        {/* Header */}
        <header className="mb-12">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">
                <span className="text-gold">SOVEREIGN ECOSYSTEM</span>{" "}
                <span className="text-3xl font-light text-foreground">Control Center</span>
              </h1>
              <p className="text-muted-foreground text-lg font-mono">
                Trustless Verification - Cryptographic Attestation - Self-Sovereign Identity
              </p>
            </div>
            <div className="text-right">
              <div className="font-mono text-sm text-muted-foreground mb-2">
                {new Date().toISOString()}
              </div>
              <div className="flex items-center gap-2 justify-end">
                <div className="w-2 h-2 rounded-full bg-accent-green pulse-glow" />
                <span className="text-sm text-foreground">All Systems Operational</span>
              </div>
            </div>
          </div>
        </header>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 md:gap-4 mb-8 border-b border-muted pb-1 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`tab whitespace-nowrap ${activeTab === tab.id ? "active" : ""}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.icon} {tab.name}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="space-y-8">
          {activeTab === "overview" && <OverviewPanel setActiveTab={setActiveTab} system={system} />}
          {activeTab === "urat" && <URATPanel setOutput={setOutput} system={system} />}
          {activeTab === "vault" && <VaultPanel setOutput={setOutput} system={system} />}
          {activeTab === "hhtps" && <HHTTPSPanel setOutput={setOutput} system={system} />}
          {activeTab === "workflows" && <WorkflowsPanel setOutput={setOutput} system={system} />}
        </div>

        {/* Output Panel */}
        {(output || system.state.lastError) && (
          <OutputPanel output={output || system.state.lastError || ""} onClear={() => setOutput("")} />
        )}
      </div>
    </div>
  )
}
