/**
 * VMO API - Create and retrieve Verifiable Memory Objects
 */

import { NextResponse } from 'next/server';
import { 
  createAgentVMO, 
  createCapabilityVMO, 
  createLogVMO,
  verifyVMOIntegrity,
  generateAgent
} from '@/lib/vmo/factory';
import { 
  addVMO, 
  getVMOById, 
  getAllVMOs, 
  getLastHash,
  getTimeline,
  logAction,
  verifyChainIntegrity
} from '@/lib/vmo/timeline';
import { createHederaClient, getTopicId, submitVMOToHCS } from '@/lib/hedera/client';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { type, payload, agentDid, privateKey, submitToHedera } = body;

    const timeline = getTimeline();
    if (!timeline) {
      return NextResponse.json({
        error: 'Timeline not initialized - call /api/boot first'
      }, { status: 400 });
    }

    const prevHash = getLastHash();
    let vmo;

    switch (type) {
      case 'agent': {
        const { name, description, publicKey, did } = payload;
        if (publicKey && did) {
          vmo = createAgentVMO(name, did, publicKey, {
            description,
            prevHash,
            privateKey
          });
        } else {
          // Generate new agent
          const generated = generateAgent(name, { description });
          vmo = generated.agent;
          // Include keys in response
          return NextResponse.json({
            vmo: generated.agent,
            privateKey: generated.privateKey,
            publicKey: generated.publicKey,
            did: generated.did,
            integrity_valid: verifyVMOIntegrity(generated.agent)
          });
        }
        break;
      }

      case 'capability': {
        const { issuedBy, issuedTo, permissions, resources, expires, maxUses } = payload;
        vmo = createCapabilityVMO(issuedBy, issuedTo, permissions, resources, {
          expires,
          maxUses,
          prevHash,
          privateKey
        });
        break;
      }

      case 'log': {
        const { action, details, data, targetVmo, capabilityId } = payload;
        vmo = createLogVMO(agentDid, action, details, {
          targetVmo,
          data,
          capabilityId,
          prevHash,
          privateKey
        });
        break;
      }

      default:
        return NextResponse.json({ error: `Unknown VMO type: ${type}` }, { status: 400 });
    }

    // Add to timeline
    addVMO(vmo);

    // Optionally submit to Hedera
    let hederaResult = null;
    if (submitToHedera) {
      const client = createHederaClient();
      if (client) {
        try {
          hederaResult = await submitVMOToHCS(client, getTopicId(), vmo);
        } catch (err) {
          console.error('[VMO] Hedera submit failed:', err);
          hederaResult = { error: 'Failed to submit to Hedera' };
        }
      } else {
        hederaResult = { error: 'Hedera client not configured' };
      }
    }

    return NextResponse.json({
      vmo,
      integrity_valid: verifyVMOIntegrity(vmo),
      hedera: hederaResult
    });

  } catch (error) {
    console.error('[VMO] Error:', error);
    return NextResponse.json({
      error: error instanceof Error ? error.message : 'Failed to create VMO'
    }, { status: 500 });
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const vmoId = searchParams.get('id');
  const type = searchParams.get('type');
  const verify = searchParams.get('verify') === 'true';

  const timeline = getTimeline();
  if (!timeline) {
    return NextResponse.json({
      error: 'Timeline not initialized'
    }, { status: 400 });
  }

  if (vmoId) {
    const vmo = getVMOById(vmoId);
    if (!vmo) {
      return NextResponse.json({ error: 'VMO not found' }, { status: 404 });
    }
    return NextResponse.json({
      vmo,
      integrity_valid: verify ? verifyVMOIntegrity(vmo) : undefined
    });
  }

  let vmos = getAllVMOs();
  
  if (type) {
    vmos = vmos.filter(v => v.type === type);
  }

  if (verify) {
    const chainIntegrity = verifyChainIntegrity();
    return NextResponse.json({
      vmos,
      count: vmos.length,
      chain_integrity: chainIntegrity
    });
  }

  return NextResponse.json({
    vmos,
    count: vmos.length
  });
}
