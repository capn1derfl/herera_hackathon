/**
 * Checkpoint API - Create Merkle roots and anchor to Hedera
 */

import { NextResponse } from 'next/server';
import { 
  createCheckpoint, 
  computeMerkleRoot, 
  getAllContentHashes,
  getTimeline,
  getAllVMOs
} from '@/lib/vmo/timeline';
import { 
  createHederaClient, 
  getTopicId, 
  anchorCheckpoint,
  verifyCheckpointAnchor 
} from '@/lib/hedera/client';
import { merkleRootSync, generateMerkleProof } from '@/lib/crypto';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { agentDid, privateKey, anchor } = body;

    const timeline = getTimeline();
    if (!timeline) {
      return NextResponse.json({
        error: 'Timeline not initialized - call /api/boot first'
      }, { status: 400 });
    }

    if (!agentDid) {
      return NextResponse.json({
        error: 'agentDid is required'
      }, { status: 400 });
    }

    // Create checkpoint VMO with Merkle root
    const checkpoint = createCheckpoint(agentDid, privateKey);

    let hederaResult = null;
    
    // Anchor to Hedera if requested
    if (anchor) {
      const client = createHederaClient();
      if (client) {
        try {
          const result = await anchorCheckpoint(client, getTopicId(), checkpoint);
          
          // Update checkpoint with anchor info
          checkpoint.payload.anchor = {
            network: process.env.HEDERA_NETWORK || 'testnet',
            topic_id: getTopicId(),
            sequence_number: result.sequenceNumber,
            transaction_id: result.transactionId,
            timestamp: new Date().toISOString()
          };

          hederaResult = {
            success: true,
            transaction_id: result.transactionId,
            sequence_number: result.sequenceNumber
          };
        } catch (err) {
          console.error('[Checkpoint] Hedera anchor failed:', err);
          hederaResult = { 
            success: false, 
            error: err instanceof Error ? err.message : 'Anchor failed' 
          };
        }
      } else {
        hederaResult = { 
          success: false, 
          error: 'Hedera client not configured - set HEDERA_ACCOUNT_ID and HEDERA_PRIVATE_KEY' 
        };
      }
    }

    return NextResponse.json({
      checkpoint,
      merkle_root: checkpoint.payload.merkle_root,
      vmo_count: checkpoint.payload.vmo_count,
      hedera: hederaResult
    });

  } catch (error) {
    console.error('[Checkpoint] Error:', error);
    return NextResponse.json({
      error: error instanceof Error ? error.message : 'Failed to create checkpoint'
    }, { status: 500 });
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');
  const vmoId = searchParams.get('vmoId');

  const timeline = getTimeline();
  if (!timeline) {
    return NextResponse.json({
      error: 'Timeline not initialized'
    }, { status: 400 });
  }

  if (action === 'merkle-root') {
    return NextResponse.json({
      merkle_root: computeMerkleRoot(),
      vmo_count: getAllVMOs().length,
      hash_count: getAllContentHashes().length
    });
  }

  if (action === 'proof' && vmoId) {
    const vmos = getAllVMOs();
    const targetVmo = vmos.find(v => v.vmo_id === vmoId);
    
    if (!targetVmo) {
      return NextResponse.json({ error: 'VMO not found' }, { status: 404 });
    }

    const hashes = getAllContentHashes();
    const proof = generateMerkleProof(hashes, targetVmo.integrity.content_hash);

    return NextResponse.json({
      vmo_id: vmoId,
      content_hash: targetVmo.integrity.content_hash,
      proof: proof?.proof || [],
      merkle_root: proof?.root || computeMerkleRoot()
    });
  }

  if (action === 'verify') {
    const checkpointId = searchParams.get('checkpointId');
    const merkleRoot = searchParams.get('merkleRoot');
    
    if (!checkpointId && !merkleRoot) {
      return NextResponse.json({
        error: 'checkpointId or merkleRoot required'
      }, { status: 400 });
    }

    const result = await verifyCheckpointAnchor(
      getTopicId(),
      checkpointId || '',
      merkleRoot || ''
    );

    return NextResponse.json(result);
  }

  // Return all checkpoints
  return NextResponse.json({
    checkpoints: timeline.checkpoints,
    current_merkle_root: computeMerkleRoot()
  });
}
