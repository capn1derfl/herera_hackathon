/**
 * URAT Bitcoin Trace API
 * Real Bitcoin transaction tracing via mempool.space
 */

import { NextResponse } from 'next/server';
import { 
  traceForward, 
  traceBackward, 
  fetchTransaction,
  fetchAddressInfo,
  detectPatterns,
  calculateRiskScore,
  generateAttestationPacket
} from '@/lib/bitcoin/tracer';
import { createAttestationVMO } from '@/lib/vmo/factory';
import { addVMO, getTimeline, getLastHash } from '@/lib/vmo/timeline';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { 
      txid, 
      direction = 'forward', 
      maxHops = 10,
      outputIndex,
      inputIndex,
      agentDid,
      privateKey,
      createAttestation = false
    } = body;

    if (!txid) {
      return NextResponse.json({
        error: 'txid is required'
      }, { status: 400 });
    }

    // Validate txid format
    if (!/^[a-fA-F0-9]{64}$/.test(txid)) {
      return NextResponse.json({
        error: 'Invalid txid format - must be 64 hex characters'
      }, { status: 400 });
    }

    // Perform trace
    const trace = direction === 'backward'
      ? await traceBackward(txid, maxHops, inputIndex)
      : await traceForward(txid, maxHops, outputIndex);

    let attestation = null;
    let attestationVmo = null;

    // Generate attestation packet
    if (createAttestation && agentDid) {
      attestation = generateAttestationPacket(trace, agentDid);

      // Create VMO for the attestation
      const timeline = getTimeline();
      if (timeline) {
        attestationVmo = createAttestationVMO(
          agentDid,
          `bitcoin:${txid}`,
          {
            trace_direction: direction,
            hops_traced: trace.total_hops,
            patterns: trace.patterns_detected,
            risk_level: trace.risk_assessment.level,
            risk_score: trace.risk_assessment.score
          },
          trace.hops.map(hop => ({
            type: 'bitcoin-transaction',
            source: 'mempool.space',
            data: hop
          })),
          1 - (trace.risk_assessment.score / 100), // Confidence inversely related to risk
          {
            prevHash: getLastHash(),
            privateKey
          }
        );
        addVMO(attestationVmo);
      }
    }

    return NextResponse.json({
      trace,
      attestation,
      attestation_vmo: attestationVmo
    });

  } catch (error) {
    console.error('[Trace] Error:', error);
    return NextResponse.json({
      error: error instanceof Error ? error.message : 'Trace failed'
    }, { status: 500 });
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const txid = searchParams.get('txid');
  const address = searchParams.get('address');

  try {
    if (txid) {
      // Fetch single transaction
      if (!/^[a-fA-F0-9]{64}$/.test(txid)) {
        return NextResponse.json({
          error: 'Invalid txid format'
        }, { status: 400 });
      }

      const tx = await fetchTransaction(txid);
      const patterns = detectPatterns(tx);
      const riskScore = calculateRiskScore(patterns);

      return NextResponse.json({
        transaction: tx,
        patterns,
        risk_score: riskScore,
        analysis: {
          input_count: tx.vin.length,
          output_count: tx.vout.length,
          total_input: tx.vin.reduce((sum, v) => sum + (v.prevout?.value || 0), 0),
          total_output: tx.vout.reduce((sum, v) => sum + v.value, 0),
          fee: tx.fee,
          confirmed: tx.status.confirmed,
          block_height: tx.status.block_height
        }
      });
    }

    if (address) {
      // Fetch address info
      const info = await fetchAddressInfo(address);
      
      return NextResponse.json({
        address: info,
        summary: {
          total_received: info.chain_stats.funded_txo_sum,
          total_sent: info.chain_stats.spent_txo_sum,
          balance: info.chain_stats.funded_txo_sum - info.chain_stats.spent_txo_sum,
          tx_count: info.chain_stats.tx_count
        }
      });
    }

    return NextResponse.json({
      error: 'txid or address parameter required'
    }, { status: 400 });

  } catch (error) {
    console.error('[Trace] GET Error:', error);
    return NextResponse.json({
      error: error instanceof Error ? error.message : 'Request failed'
    }, { status: 500 });
  }
}
