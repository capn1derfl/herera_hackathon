/**
 * Boot API - Initialize sovereign system from Hedera HCS
 */

import { NextResponse } from 'next/server';
import { bootFromHedera, getTopicId } from '@/lib/hedera/client';
import { initializeTimeline, createFreshTimeline, getTimelineStats } from '@/lib/vmo/timeline';
import { generateAgent, createAgentVMO } from '@/lib/vmo/factory';

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const { topicId, forceNew } = body;

    const topic = topicId || getTopicId();

    if (forceNew) {
      // Create fresh timeline without reading from Hedera
      const { agent, privateKey, publicKey, did } = generateAgent('ARCHZERO', {
        description: 'Sovereign Ecosystem Control Agent'
      });

      const timeline = createFreshTimeline(did, topic);
      
      // Add the genesis agent to timeline
      initializeTimeline(timeline);

      return NextResponse.json({
        status: 'initialized',
        mode: 'fresh',
        topic_id: topic,
        agent: {
          did,
          public_key: publicKey,
          private_key: privateKey, // Return for client storage
          vmo_id: agent.vmo_id
        },
        stats: getTimelineStats(),
        message: 'Fresh timeline created - not connected to Hedera yet'
      });
    }

    // Boot from Hedera
    const bootState = await bootFromHedera(topic);

    // Initialize runtime timeline
    initializeTimeline(bootState.timeline);

    return NextResponse.json({
      status: 'booted',
      mode: 'hedera',
      topic_id: topic,
      integrity_valid: bootState.integrity_valid,
      message_count: bootState.message_count,
      last_sequence: bootState.last_sequence,
      last_checkpoint: bootState.last_checkpoint?.vmo_id,
      stats: getTimelineStats(),
      agent: bootState.timeline.meta.agent
    });

  } catch (error) {
    console.error('[Boot] Error:', error);
    return NextResponse.json({
      status: 'error',
      error: error instanceof Error ? error.message : 'Boot failed'
    }, { status: 500 });
  }
}

export async function GET() {
  // Return current boot status
  const stats = getTimelineStats();
  
  return NextResponse.json({
    initialized: stats.initialized,
    stats,
    topic_id: getTopicId()
  });
}
