"use client"

interface OutputPanelProps {
  output: string
  onClear: () => void
}

export function OutputPanel({ output, onClear }: OutputPanelProps) {
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-xl font-semibold text-gold">System Output</h3>
        <button
          className="btn-gold btn-secondary px-4 py-2 rounded-lg text-sm font-medium"
          onClick={onClear}
        >
          Clear
        </button>
      </div>
      <div className="output-panel scrollbar-custom font-mono text-sm text-foreground">
        {output}
      </div>
    </div>
  )
}
