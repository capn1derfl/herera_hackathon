"use client"

import { useState } from "react"

interface URATFormData {
  txid: string
  direction: "forward" | "backward"
  maxHops: string
  notes: string
}

interface URATTracePanelProps {
  setOutput: (output: string) => void
  system?: {
    state: {
      vmosCreated: number
      checkpoints: number
      proofGenerated: number
      agentsActive: number
      lastBoot: string | null
      topicId: string
      lastError: string | null
      isBootstrapped: boolean
    }
    loading: boolean
    traceTransaction: (txid: string, depth: number) => Promise<any>
  }
}

export function URATPanel({ setOutput, system }: URATTracePanelProps) {
  const [mode, setMode] = useState<"trace" | "analyze" | "attest">("trace")
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState<URATFormData>({
    txid: "",
    direction: "forward",
    maxHops: "5",
    notes: "",
  })

  const handleTrace = async () => {
    if (!formData.txid) {
      setOutput("Error: Transaction ID is required")
      return
    }

    setIsLoading(true)
    setOutput(`[URAT v0.2] Initiating ${formData.direction} trace from mempool.space...\nTXID: ${formData.txid}\n\nPlease wait...`)

    try {
      let data
      
      if (system && system.traceTransaction) {
        data = await system.traceTransaction(formData.txid, parseInt(formData.maxHops))
      } else {
        const response = await fetch("/api/trace", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            txid: formData.txid,
            direction: formData.direction,
            maxHops: parseInt(formData.maxHops),
            createAttestation: mode === "attest",
          }),
        })
        data = await response.json()
      }

      if (data.error) {
        setOutput(`[URAT v0.2] Error: ${data.error}`)
        return
      }

      const trace = data.trace
      let output = `[URAT v0.2 Bitcoin Tracer - LIVE DATA]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Direction: ${trace.direction.toUpperCase()}
Start TXID: ${trace.start_txid}
Total Hops Traced: ${trace.total_hops}
Addresses Involved: ${trace.addresses_involved.length}
Total Value Traced: ${(trace.total_value_traced / 100000000).toFixed(8)} BTC

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RISK ASSESSMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Risk Level: ${trace.risk_assessment.level.toUpperCase()}
Risk Score: ${trace.risk_assessment.score}/100
Patterns Detected: ${trace.patterns_detected.length > 0 ? trace.patterns_detected.join(", ") : "None"}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROVENANCE CHAIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`
      for (const hop of trace.hops) {
        const date = hop.timestamp ? new Date(hop.timestamp * 1000).toISOString() : "Unconfirmed"
        output += `
Hop ${hop.hop}: ${hop.txid.slice(0, 16)}...${hop.txid.slice(-8)}
  Block: ${hop.block_height || "Mempool"}
  Time: ${date}
  Inputs: ${hop.inputs.length} | Outputs: ${hop.outputs.length}
  Fee: ${hop.fee} sats
  Patterns: ${hop.patterns.length > 0 ? hop.patterns.join(", ") : "None"}
  Risk: ${hop.risk_score}
`
      }

      if (data.attestation) {
        output += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ATTESTATION PACKET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${JSON.stringify(data.attestation, null, 2)}
`
      }

      if (data.attestation_vmo) {
        output += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ATTESTATION VMO CREATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VMO ID: ${data.attestation_vmo.vmo_id}
Content Hash: ${data.attestation_vmo.integrity.content_hash}
`
      }

      setOutput(output)
    } catch (err) {
      setOutput(`[URAT v0.2] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAnalyze = async () => {
    if (!formData.txid) {
      setOutput("Error: Transaction ID is required")
      return
    }

    setIsLoading(true)
    setOutput(`[URAT v0.2] Fetching transaction from mempool.space...\nTXID: ${formData.txid}`)

    try {
      const response = await fetch(`/api/trace?txid=${formData.txid}`)
      const data = await response.json()

      if (data.error) {
        setOutput(`[URAT v0.2] Error: ${data.error}`)
        return
      }

      const tx = data.transaction
      const output = `[URAT v0.2 Transaction Analysis - LIVE DATA]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TXID: ${tx.txid}
Status: ${tx.status.confirmed ? `Confirmed at block ${tx.status.block_height}` : "Unconfirmed (Mempool)"}
Block Time: ${tx.status.block_time ? new Date(tx.status.block_time * 1000).toISOString() : "N/A"}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TRANSACTION METRICS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Inputs: ${data.analysis.input_count}
Outputs: ${data.analysis.output_count}
Total Input: ${(data.analysis.total_input / 100000000).toFixed(8)} BTC
Total Output: ${(data.analysis.total_output / 100000000).toFixed(8)} BTC
Fee: ${data.analysis.fee} sats (${(data.analysis.fee / tx.weight * 4).toFixed(2)} sat/vB)
Size: ${tx.size} bytes | Weight: ${tx.weight} WU

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PATTERN ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Patterns Detected: ${data.patterns.length > 0 ? data.patterns.join(", ") : "None"}
Risk Score: ${data.risk_score}/100

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INPUTS (${tx.vin.length})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${tx.vin.map((v: any, i: number) => `
[${i}] ${v.prevout?.scriptpubkey_address || "Coinbase"}
    Value: ${((v.prevout?.value || 0) / 100000000).toFixed(8)} BTC
    From: ${v.txid?.slice(0, 16)}...`).join("\n")}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OUTPUTS (${tx.vout.length})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${tx.vout.map((v: any, i: number) => `
[${i}] ${v.scriptpubkey_address || "OP_RETURN"}
    Value: ${(v.value / 100000000).toFixed(8)} BTC
    Type: ${v.scriptpubkey_type}`).join("\n")}
`
      setOutput(output)
    } catch (err) {
      setOutput(`[URAT v0.2] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAction = () => {
    if (mode === "analyze") {
      handleAnalyze()
    } else {
      handleTrace()
    }
  }

  return (
    <div className="space-y-6">
      <div className="sovereign-card p-6">
        <h2 className="text-3xl font-bold mb-4 text-gold">{"\u20BF"} URAT v0.2 Bitcoin Tracer</h2>
        <p className="text-muted-foreground mb-6">
          Real Bitcoin transaction tracing via mempool.space API
        </p>

        {/* Mode Selection */}
        <div className="flex flex-wrap gap-4 mb-6">
          <button
            className={`btn-gold py-2 px-4 rounded-lg ${mode === "trace" ? "" : "btn-secondary"}`}
            onClick={() => setMode("trace")}
          >
            Trace Chain
          </button>
          <button
            className={`btn-gold py-2 px-4 rounded-lg ${mode === "analyze" ? "" : "btn-secondary"}`}
            onClick={() => setMode("analyze")}
          >
            Analyze TX
          </button>
          <button
            className={`btn-gold py-2 px-4 rounded-lg ${mode === "attest" ? "" : "btn-secondary"}`}
            onClick={() => setMode("attest")}
          >
            Trace + Attest
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2 text-gold">
              Transaction ID (TXID)
            </label>
            <input
              type="text"
              placeholder="64-character hex transaction ID"
              value={formData.txid}
              onChange={(e) => setFormData({ ...formData, txid: e.target.value.trim() })}
              className="sovereign-input font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Example: 4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b
            </p>
          </div>
          
          {mode !== "analyze" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gold">Direction</label>
                <select
                  value={formData.direction}
                  onChange={(e) => setFormData({ ...formData, direction: e.target.value as "forward" | "backward" })}
                  className="sovereign-input"
                >
                  <option value="forward">Forward (follow spent outputs)</option>
                  <option value="backward">Backward (follow inputs)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2 text-gold">Max Hops</label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={formData.maxHops}
                  onChange={(e) => setFormData({ ...formData, maxHops: e.target.value })}
                  className="sovereign-input"
                />
              </div>
            </div>
          )}

          <button 
            className="btn-gold w-full py-3 rounded-lg text-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2" 
            onClick={handleAction}
            disabled={isLoading || !formData.txid}
          >
            {isLoading ? (
              <>
                <span className="animate-spin">&#9696;</span>
                Tracing...
              </>
            ) : mode === "analyze" ? (
              "Analyze Transaction"
            ) : mode === "attest" ? (
              "Trace & Create Attestation VMO"
            ) : (
              "Execute Live Trace"
            )}
          </button>
        </div>
      </div>

      {/* Capabilities */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-gold">Pattern Detection</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- Possible CoinJoin</li>
            <li>- Fan-out patterns</li>
            <li>- Peel chains</li>
            <li>- Consolidation</li>
            <li>- Self-transfers</li>
            <li>- Round amounts</li>
          </ul>
        </div>
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-blue">Risk Scoring</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- Weighted analysis</li>
            <li>- Per-hop scoring</li>
            <li>- Risk classification</li>
            <li>- Pattern correlation</li>
            <li>- low/medium/high/critical</li>
          </ul>
        </div>
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-purple">VMO Attestations</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- Cryptographic proof</li>
            <li>- Chain-linked evidence</li>
            <li>- SHA-256 content hash</li>
            <li>- Ed25519 signatures</li>
            <li>- Hedera anchoring</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
