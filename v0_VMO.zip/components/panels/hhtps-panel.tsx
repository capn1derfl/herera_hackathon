"use client"

import { useState } from "react"

interface HHTTPSPanelProps {
  setOutput: (output: string) => void
  system?: {
    state: {
      vmosCreated: number
      checkpoints: number
      proofGenerated: number
      agentsActive: number
      lastBoot: string | null
      topicId: string
      lastError: string | null
      isBootstrapped: boolean
    }
    loading: boolean
  }
}

interface ProofData {
  namespace: string
  kind: string
  subkind: string
  resource: string
  issuer: string
  claim: string
}

export function HHTTPSPanel({ setOutput, system }: HHTTPSPanelProps) {
  const [proofData, setProofData] = useState<ProofData>({
    namespace: "ZKP",
    kind: "proof",
    subkind: "credential",
    resource: "CERTIFIED_DEV",
    issuer: "did:zpid:issuer123",
    claim: "OVER18",
  })

  const handleGenerateProof = () => {
    const uri = `hhtps://blocksavvy.zeropoint.id/${proofData.namespace}/${proofData.kind}/${proofData.subkind}/${proofData.resource}`
    const uuid = crypto.randomUUID()
    
    setOutput(`[hhtps:// Protocol - Proof URI Generator]
Generating sovereign proof URI...

Canonical URI:
${uri}

Resolver Endpoint:
https://blocksavvy.zeropoint.id/${proofData.namespace}/${proofData.kind}/${proofData.subkind}/${proofData.resource}.json

Proof Object (JSON Schema):
{
  "id": "urn:uuid:${uuid}",
  "issuer": "${proofData.issuer}",
  "issuedAt": "${new Date().toISOString()}",
  "expiresAt": "${new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()}",
  "claim": {
    "type": "${proofData.claim}",
    "data": {}
  },
  "roots": {
    "merkle": "sha256:[MERKLE_ROOT]",
    "zk": null
  },
  "anchors": {
    "hedera": {
      "topic": "0.0.XXXXXX",
      "sequence": 12345,
      "timestamp": "${new Date().toISOString()}"
    },
    "ethereum": null,
    "ipfs": null
  },
  "proof": {
    "alg": "Ed25519",
    "kid": "${proofData.issuer}#key-1",
    "sig": "[BASE64_SIGNATURE]"
  }
}

Verification Process:
1. Parse URI structure
2. Fetch .json endpoint via HTTPS
3. Validate against JSON Schema
4. Canonicalize using JCS (RFC 8785)
5. Verify signature with issuer's public key
6. Check timestamp window
7. Verify optional anchors

✓ Proof URI generated
✓ Agent-readable format
✓ Chain-agnostic
✓ Signature-bound`)
  }

  return (
    <div className="space-y-6">
      <div className="sovereign-card p-6">
        <h2 className="text-3xl font-bold mb-4 text-accent-purple">
          {"\u26A1"} hhtps:// Protocol
        </h2>
        <p className="text-muted-foreground mb-6">
          Proof-native URI scheme for sovereign interoperability
        </p>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-accent-purple">
                Namespace
              </label>
              <input
                type="text"
                value={proofData.namespace}
                onChange={(e) => setProofData({ ...proofData, namespace: e.target.value })}
                className="sovereign-input"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2 text-accent-purple">
                Proof Kind
              </label>
              <input
                type="text"
                value={proofData.kind}
                onChange={(e) => setProofData({ ...proofData, kind: e.target.value })}
                className="sovereign-input"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-accent-purple">
                Subkind
              </label>
              <input
                type="text"
                value={proofData.subkind}
                onChange={(e) => setProofData({ ...proofData, subkind: e.target.value })}
                className="sovereign-input"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2 text-accent-purple">
                Resource
              </label>
              <input
                type="text"
                value={proofData.resource}
                onChange={(e) => setProofData({ ...proofData, resource: e.target.value })}
                className="sovereign-input"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2 text-accent-purple">
              Issuer DID
            </label>
            <input
              type="text"
              value={proofData.issuer}
              onChange={(e) => setProofData({ ...proofData, issuer: e.target.value })}
              className="sovereign-input"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2 text-accent-purple">
              Claim Type
            </label>
            <input
              type="text"
              value={proofData.claim}
              onChange={(e) => setProofData({ ...proofData, claim: e.target.value })}
              className="sovereign-input"
            />
          </div>
          <button
            className="btn-gold w-full py-3 rounded-lg text-lg"
            onClick={handleGenerateProof}
          >
            Generate Proof URI
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-purple">URI Structure</h4>
          <div className="text-sm text-muted-foreground font-mono space-y-1">
            <p>{"hhtps://{host}/"}</p>
            <p className="pl-4">{"{NAMESPACE}/"}</p>
            <p className="pl-4">{"{PROOF_KIND}/"}</p>
            <p className="pl-4">{"{SUBKIND}/"}</p>
            <p className="pl-4">{"{RESOURCE}"}</p>
          </div>
        </div>
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-purple">Network Support</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>Hedera HCS (topics/files)</li>
            <li>Ethereum (tx/logs)</li>
            <li>IPFS (CIDs)</li>
            <li>HTTPS mirrors</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
