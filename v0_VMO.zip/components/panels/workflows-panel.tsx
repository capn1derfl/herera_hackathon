"use client"

interface WorkflowsPanelProps {
  setOutput: (output: string) => void
  system?: {
    state: {
      vmosCreated: number
      checkpoints: number
      proofGenerated: number
      agentsActive: number
      lastBoot: string | null
      topicId: string
      lastError: string | null
      isBootstrapped: boolean
    }
    loading: boolean
  }
}

interface Workflow {
  id: string
  name: string
  description: string
  steps: string[]
}

const workflows: Workflow[] = [
  {
    id: "urat-to-vault",
    name: "URAT → Vault Integration",
    description: "Store Bitcoin provenance chains as VMOs",
    steps: [
      "Trace Bitcoin transaction using URAT",
      "Generate attestation packet",
      "Create VMO with provenance data",
      "Sign with agent credentials",
      "Anchor checkpoint to Hedera",
    ],
  },
  {
    id: "vault-to-hhtps",
    name: "Vault → hhtps:// Export",
    description: "Generate portable proof URIs from VMOs",
    steps: [
      "Select VMO from vault",
      "Extract claim and metadata",
      "Generate hhtps:// URI",
      "Create proof object JSON",
      "Publish to resolver endpoint",
    ],
  },
  {
    id: "full-stack",
    name: "Full Stack: Asset Recovery",
    description: "Complete workflow from trace to court submission",
    steps: [
      "Trace stolen Bitcoin with URAT",
      "Create agent VMO for investigator",
      "Store provenance chain in vault",
      "Generate court attestation packet",
      "Anchor to Hedera HCS",
      "Create hhtps:// proof URI",
      "Generate custodian freeze request",
      "Submit bundle to court",
    ],
  },
]

export function WorkflowsPanel({ setOutput, system }: WorkflowsPanelProps) {
  const handleExecuteWorkflow = (workflow: Workflow) => {
    const stepsFormatted = workflow.steps.map((step, idx) => `${idx + 1}. ${step}`).join("\n")

    let executionPlan = ""

    if (workflow.id === "urat-to-vault") {
      executionPlan = `
// Step 1: URAT Trace
const urat = require('./bitcoin_trace_pro.py');
const provenance = await urat.trace({
  address: 'bc1q...',
  hops: 10
});

// Step 2: Create VMO
const { createVMO } = require('./sovereignVaultCore');
const vmo = createVMO({
  type: 'urat_provenance',
  payload: provenance,
  agent_did: 'did:zpid:investigator',
  scope: 'shared',
  tags: ['bitcoin', 'recovery']
});

// Step 3: Anchor
const { anchorCheckpoint } = require('./index');
await anchorCheckpoint({
  agent_did: 'did:zpid:investigator',
  capability_id: 'cap:recovery:full'
});

✓ Provenance stored as VMO
✓ Checkpoint anchored to Hedera
✓ Immutable audit trail created`
    } else if (workflow.id === "vault-to-hhtps") {
      executionPlan = `
// Step 1: Fetch VMO
const vmo = Vault.vmos['vmo:urat:000123'];

// Step 2: Create Proof Object
const proof = {
  id: 'urn:uuid:' + crypto.randomUUID(),
  issuer: vmo.provenance.agent_did,
  claim: {
    type: 'BITCOIN_PROVENANCE',
    data: vmo.payload
  },
  anchors: {
    hedera: { topic: '0.0.XXXXX' }
  },
  proof: {
    alg: 'Ed25519',
    sig: '[SIGNATURE]'
  }
};

// Step 3: Generate URI
const uri = 'hhtps://blocksavvy.zeropoint.id/URAT/provenance/bitcoin/' + vmo.vmo_id;

✓ Proof URI generated
✓ Portable across systems
✓ Agent-readable format`
    } else {
      executionPlan = `
// Complete Asset Recovery Workflow

1. Trace stolen funds
   → python3 bitcoin_trace_pro.py --trace bc1q... --hops 15

2. Initialize vault & create agent
   → const vault = require('./index');
   → vault.init();
   → const agent = vault.createAgentVMO({...});

3. Store provenance
   → const vmo = vault.act({
       action: 'create',
       type: 'urat_provenance',
       payload: provenanceChain
     });

4. Generate attestation bundle
   → Court memo, custodian request, manifest

5. Anchor to Hedera
   → vault.anchorCheckpoint({...});

6. Create portable proof
   → hhtps://blocksavvy.zeropoint.id/URAT/proof/recovery/case_001

7. Submit to court
   → Exhibits A-E with SHA256 verification

✓ End-to-end verifiable chain
✓ Court-ready documentation
✓ Cryptographically provable`
    }

    setOutput(`[Integration Workflow: ${workflow.name}]
Executing multi-system workflow...

${workflow.description}

Steps:
${stepsFormatted}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Execution Plan:
${executionPlan}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: Ready for execution
All systems operational`)
  }

  return (
    <div className="space-y-6">
      <div className="sovereign-card p-6">
        <h2 className="text-3xl font-bold mb-4 text-gold">
          {"\u2299"} Integration Workflows
        </h2>
        <p className="text-muted-foreground mb-6">
          Multi-system processes combining URAT, Vault, and hhtps://
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {workflows.map((workflow) => (
          <div key={workflow.id} className="sovereign-card p-6">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-2 text-gold">{workflow.name}</h3>
                <p className="text-muted-foreground text-sm">{workflow.description}</p>
              </div>
              <button
                className="btn-gold py-2 px-6 rounded-lg whitespace-nowrap"
                onClick={() => handleExecuteWorkflow(workflow)}
              >
                Execute
              </button>
            </div>
            <div className="space-y-2">
              {workflow.steps.map((step, idx) => (
                <div key={idx} className="flex items-center gap-3 text-sm">
                  <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs text-gold font-semibold">
                    {idx + 1}
                  </div>
                  <span className="text-foreground/80">{step}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
