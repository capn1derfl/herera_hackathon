"use client"

import { useState, useEffect } from "react"

type TabId = "overview" | "urat" | "vault" | "hhtps" | "workflows"

interface OverviewPanelProps {
  setActiveTab: (tab: TabId) => void
  system?: {
    state: {
      vmosCreated: number
      checkpoints: number
      proofGenerated: number
      agentsActive: number
      lastBoot: string | null
      topicId: string
      lastError: string | null
      isBootstrapped: boolean
    }
    loading: boolean
    boot: () => Promise<void>
  }
}

interface SystemStats {
  initialized: boolean
  stats?: {
    totalVmos: number
    agents: number
    capabilities: number
    logs: number
    checkpoints: number
    merkleRoot: string
  }
  topic_id?: string
}

const systems = [
  {
    id: "urat" as TabId,
    name: "URAT v0.2 Bitcoin Tracer",
    icon: "\u20BF",
    colorClass: "text-gold",
    description: "Real Bitcoin tracing via mempool.space API",
    capabilities: [
      "Live transaction tracing",
      "Pattern detection",
      "Risk scoring",
      "VMO attestations",
      "Provenance chains",
      "Court-ready evidence",
    ],
    status: "active",
  },
  {
    id: "vault" as TabId,
    name: "Sovereign Vault",
    icon: "\u2B22",
    colorClass: "text-accent-blue",
    description: "VMOs with Ed25519 signatures and Hedera anchoring",
    capabilities: [
      "Real Ed25519 crypto",
      "SHA-256 hashing",
      "RFC 8785 JCS",
      "Merkle trees",
      "Hedera HCS boot",
      "Chain integrity",
    ],
    status: "active",
  },
  {
    id: "hhtps" as TabId,
    name: "hhtps:// Protocol",
    icon: "\u26A1",
    colorClass: "text-accent-purple",
    description: "Proof-native URI scheme for sovereign interoperability",
    capabilities: [
      "Chain-agnostic URIs",
      "JCS canonicalization",
      "Signature binding",
      "Multi-network anchors",
      "Portable proofs",
      "Agent-readable",
    ],
    status: "active",
  },
  {
    id: "overview" as TabId,
    name: "Self-Sovereign Identity",
    icon: "\u25C9",
    colorClass: "text-accent-green",
    description: "Trustless verification without gatekeepers",
    capabilities: [
      "Proof-based auth",
      "Fraud-proof creds",
      "Cross-network",
      "Zero-trust",
      "Permission-free",
      "Self-executing",
    ],
    status: "active",
  },
]

export function OverviewPanel({ setActiveTab, system }: OverviewPanelProps) {
  const [stats, setStats] = useState<SystemStats>({ initialized: false })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (system) {
      setStats({
        initialized: system.state.isBootstrapped,
        stats: {
          totalVmos: system.state.vmosCreated,
          agents: system.state.agentsActive,
          capabilities: 0,
          logs: 0,
          checkpoints: system.state.checkpoints,
          merkleRoot: "",
        },
        topic_id: system.state.topicId,
      })
      setIsLoading(system.loading)
    } else {
      fetch("/api/boot")
        .then(res => res.json())
        .then(data => {
          setStats(data)
          setIsLoading(false)
        })
        .catch(() => setIsLoading(false))
    }
  }, [system])

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6 text-gold">System Architecture</h2>

      {/* Status Banner */}
      <div className="sovereign-card p-4 mb-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {stats.initialized ? (
              <>
                <div className="w-3 h-3 rounded-full bg-accent-green pulse-glow" />
                <span className="text-accent-green font-semibold">SYSTEM ONLINE</span>
                <span className="text-muted-foreground">|</span>
                <span className="text-sm text-muted-foreground font-mono">
                  Topic: {stats.topic_id || "0.0.7564883"}
                </span>
              </>
            ) : (
              <>
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="text-amber-500 font-semibold">NOT INITIALIZED</span>
                <span className="text-sm text-muted-foreground">
                  Go to Sovereign Vault to boot from Hedera
                </span>
              </>
            )}
          </div>
          <button
            className="btn-gold py-2 px-4 rounded-lg text-sm"
            onClick={() => setActiveTab("vault")}
          >
            {stats.initialized ? "View Vault" : "Boot System"}
          </button>
        </div>
      </div>

      {/* Systems Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {systems.map((system) => (
          <div
            key={system.id + system.name}
            className="sovereign-card p-6 cursor-pointer"
            onClick={() => system.id !== "overview" && setActiveTab(system.id)}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className={`text-3xl ${system.colorClass}`}>{system.icon}</span>
                  <h3 className="text-2xl font-semibold text-foreground">{system.name}</h3>
                </div>
                <p className="text-muted-foreground text-sm">{system.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent-green pulse-glow" />
                <span className="text-xs text-muted-foreground font-mono">
                  {system.status.toUpperCase()}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              {system.capabilities.map((cap, idx) => (
                <div key={idx} className="capability-badge text-foreground">
                  {cap}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Integration Flow */}
      <div className="sovereign-card p-8 mb-8">
        <h3 className="text-2xl font-semibold mb-6 text-gold">Integration Architecture</h3>
        <svg width="100%" height="300" viewBox="0 0 800 300" className="mb-8">
          {/* Connections */}
          <path className="integration-line" d="M 200 60 L 600 60" />
          <path className="integration-line" d="M 200 60 L 200 240" />
          <path className="integration-line" d="M 600 60 L 600 240" />
          <path className="integration-line" d="M 200 240 L 600 240" />
          <path className="integration-line" d="M 400 60 L 400 240" />

          {/* Nodes */}
          <g>
            <circle className="node-dot" cx={200} cy={60} r={8} />
            <text x={200} y={40} textAnchor="middle" fill="#d4af37" fontSize="14" fontFamily="Rajdhani">
              {"\u20BF"} URAT
            </text>

            <circle className="node-dot" cx={600} cy={60} r={8} />
            <text x={600} y={40} textAnchor="middle" fill="#6b9bd1" fontSize="14" fontFamily="Rajdhani">
              {"\u2B22"} Vault
            </text>

            <circle className="node-dot" cx={400} cy={150} r={8} />
            <text x={400} y={130} textAnchor="middle" fill="#9c88ff" fontSize="14" fontFamily="Rajdhani">
              {"\u26A1"} hhtps://
            </text>

            <circle className="node-dot" cx={200} cy={240} r={8} />
            <text x={200} y={270} textAnchor="middle" fill="#7cb342" fontSize="14" fontFamily="Rajdhani">
              {"\u25C9"} SSI
            </text>

            <circle className="node-dot" cx={600} cy={240} r={8} />
            <text x={600} y={270} textAnchor="middle" fill="#d4af37" fontSize="14" fontFamily="Rajdhani">
              {"\u2299"} Hedera
            </text>
          </g>
        </svg>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
          <div>
            <strong className="text-gold block mb-2">Data Flow:</strong>
            <p>URAT traces Bitcoin provenance</p>
            <p>Vault stores VMOs with integrity</p>
            <p>hhtps:// creates portable proofs</p>
          </div>
          <div>
            <strong className="text-accent-blue block mb-2">Verification:</strong>
            <p>Ed25519 signatures (real)</p>
            <p>RFC 8785 JCS canonicalization</p>
            <p>Hedera HCS anchoring</p>
          </div>
          <div>
            <strong className="text-accent-purple block mb-2">Output:</strong>
            <p>Verifiable attestations</p>
            <p>Merkle proofs</p>
            <p>Self-sovereign credentials</p>
          </div>
        </div>
      </div>

      {/* Quick Actions & Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="sovereign-card p-6">
          <h4 className="font-semibold mb-3 text-gold">Quick Start</h4>
          <button
            className="btn-gold w-full mb-2 py-2 rounded-lg"
            onClick={() => setActiveTab("urat")}
          >
            Trace Bitcoin Transaction
          </button>
          <button
            className="btn-gold btn-secondary w-full mb-2 py-2 rounded-lg"
            onClick={() => setActiveTab("vault")}
          >
            Boot / Create VMO
          </button>
          <button
            className="btn-gold btn-secondary w-full py-2 rounded-lg"
            onClick={() => setActiveTab("hhtps")}
          >
            Generate Proof URI
          </button>
        </div>
        <div className="sovereign-card p-6">
          <h4 className="font-semibold mb-3 text-accent-blue">Live Metrics</h4>
          {isLoading ? (
            <p className="text-muted-foreground text-sm">Loading...</p>
          ) : stats.initialized && stats.stats ? (
            <div className="space-y-2 text-sm font-mono">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total VMOs:</span>
                <span className="text-gold">{stats.stats.totalVmos}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Agents:</span>
                <span className="text-gold">{stats.stats.agents}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Capabilities:</span>
                <span className="text-gold">{stats.stats.capabilities}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Checkpoints:</span>
                <span className="text-gold">{stats.stats.checkpoints}</span>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">
              Boot the system to see live metrics
            </p>
          )}
        </div>
        <div className="sovereign-card p-6">
          <h4 className="font-semibold mb-3 text-accent-purple">Configuration</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${stats.initialized ? 'bg-accent-green' : 'bg-amber-500'}`} />
              <span className="text-muted-foreground">Hedera Client</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent-green" />
              <span className="text-muted-foreground">mempool.space API</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent-green" />
              <span className="text-muted-foreground">Ed25519 Crypto</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            Set HEDERA_ACCOUNT_ID, HEDERA_PRIVATE_KEY in env vars to enable full Hedera integration.
          </p>
        </div>
      </div>
    </div>
  )
}
