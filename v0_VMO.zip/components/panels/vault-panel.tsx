"use client"

import { useState, useEffect } from "react"

interface VaultPanelProps {
  setOutput: (output: string) => void
  system?: {
    state: {
      vmosCreated: number
      checkpoints: number
      proofGenerated: number
      agentsActive: number
      lastBoot: string | null
      topicId: string
      lastError: string | null
      isBootstrapped: boolean
    }
    loading: boolean
    boot: () => Promise<void>
    createVMO: (type: string, payload: any) => Promise<any>
    createCheckpoint: (vmoIds: string[]) => Promise<any>
  }
}

type VaultAction = "boot" | "createAgent" | "createCapability" | "checkpoint" | "viewVMOs"

interface BootState {
  initialized: boolean
  agent?: string
  privateKey?: string
  stats?: {
    totalVmos: number
    agents: number
    capabilities: number
    logs: number
    checkpoints: number
    merkleRoot: string
  }
}

export function VaultPanel({ setOutput, system }: VaultPanelProps) {
  const [action, setAction] = useState<VaultAction>("boot")
  const [isLoading, setIsLoading] = useState(false)
  const [bootState, setBootState] = useState<BootState>({ initialized: false })
  const [agentName, setAgentName] = useState("ARCHZERO")
  const [capTarget, setCapTarget] = useState("")
  const [capPermissions, setCapPermissions] = useState("read,write")

  // Check boot status on mount
  useEffect(() => {
    if (system) {
      setBootState({
        initialized: system.state.isBootstrapped,
        stats: {
          totalVmos: system.state.vmosCreated,
          agents: system.state.agentsActive,
          capabilities: 0,
          logs: 0,
          checkpoints: system.state.checkpoints,
          merkleRoot: "",
        },
      })
    } else {
      fetch("/api/boot")
        .then(res => res.json())
        .then(data => {
          if (data.initialized) {
            setBootState({ initialized: true, stats: data.stats })
          }
        })
        .catch(() => {})
    }
  }, [system])

  const handleBoot = async (forceNew: boolean = false) => {
    setIsLoading(true)
    setOutput(`[Sovereign Vault] ${forceNew ? "Creating fresh timeline..." : "Booting from Hedera HCS..."}\nTopic: 0.0.7564883\n\nPlease wait...`)

    try {
      const response = await fetch("/api/boot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ forceNew }),
      })

      const data = await response.json()

      if (data.error) {
        setOutput(`[Sovereign Vault] Boot Error: ${data.error}`)
        return
      }

      setBootState({
        initialized: true,
        agent: data.agent?.did || data.agent,
        privateKey: data.agent?.private_key,
        stats: data.stats,
      })

      let output = `[Sovereign Vault - ${data.mode === 'hedera' ? 'HEDERA BOOT' : 'FRESH INIT'}]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Status: ${data.status.toUpperCase()}
Mode: ${data.mode}
Topic ID: ${data.topic_id}
`

      if (data.mode === 'hedera') {
        output += `
Integrity: ${data.integrity_valid ? 'VALID' : 'BROKEN - CHAIN TAMPERED'}
Messages Read: ${data.message_count}
Last Sequence: ${data.last_sequence}
Last Checkpoint: ${data.last_checkpoint || 'None'}
`
      }

      output += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TIMELINE STATS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Total VMOs: ${data.stats.totalVmos}
Agents: ${data.stats.agents}
Capabilities: ${data.stats.capabilities}
Logs: ${data.stats.logs}
Checkpoints: ${data.stats.checkpoints}
Merkle Root: ${data.stats.merkleRoot || 'Empty'}
`

      if (data.agent?.private_key) {
        output += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AGENT CREDENTIALS (SAVE THESE!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DID: ${data.agent.did}
Public Key: ${data.agent.public_key}
Private Key: ${data.agent.private_key}

WARNING: Save the private key securely!
`
      }

      setOutput(output)
    } catch (err) {
      setOutput(`[Sovereign Vault] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateAgent = async () => {
    if (!bootState.initialized) {
      setOutput("[Sovereign Vault] Error: Boot the system first")
      return
    }

    setIsLoading(true)
    setOutput(`[Sovereign Vault] Creating agent: ${agentName}...`)

    try {
      const response = await fetch("/api/vmo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "agent",
          payload: { name: agentName, description: "Created from Control Center" },
        }),
      })

      const data = await response.json()

      if (data.error) {
        setOutput(`[Sovereign Vault] Error: ${data.error}`)
        return
      }

      const output = `[Sovereign Vault - AGENT CREATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VMO ID: ${data.vmo.vmo_id}
Type: agent
Integrity Valid: ${data.integrity_valid}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AGENT DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DID: ${data.did}
Name: ${agentName}
Public Key: ed25519:${data.publicKey}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CREDENTIALS (SAVE SECURELY!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Private Key: ${data.privateKey}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VMO STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${JSON.stringify(data.vmo, null, 2)}
`
      setOutput(output)
    } catch (err) {
      setOutput(`[Sovereign Vault] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateCapability = async () => {
    if (!bootState.initialized || !bootState.agent) {
      setOutput("[Sovereign Vault] Error: Boot the system first")
      return
    }

    if (!capTarget) {
      setOutput("[Sovereign Vault] Error: Target DID is required")
      return
    }

    setIsLoading(true)
    setOutput(`[Sovereign Vault] Issuing capability to ${capTarget}...`)

    try {
      const response = await fetch("/api/vmo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "capability",
          payload: {
            issuedBy: bootState.agent,
            issuedTo: capTarget,
            permissions: capPermissions.split(",").map(p => p.trim()),
            resources: ["vmo:*"],
            expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          },
          agentDid: bootState.agent,
          privateKey: bootState.privateKey,
        }),
      })

      const data = await response.json()

      if (data.error) {
        setOutput(`[Sovereign Vault] Error: ${data.error}`)
        return
      }

      const output = `[Sovereign Vault - CAPABILITY ISSUED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VMO ID: ${data.vmo.vmo_id}
Capability ID: ${data.vmo.payload.capability_id}
Integrity Valid: ${data.integrity_valid}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CAPABILITY DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Issued By: ${data.vmo.payload.issued_by}
Issued To: ${data.vmo.payload.issued_to}
Permissions: ${data.vmo.payload.permissions.join(", ")}
Resources: ${data.vmo.payload.resources.join(", ")}
Expires: ${data.vmo.payload.constraints.expires}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VMO STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${JSON.stringify(data.vmo, null, 2)}
`
      setOutput(output)
    } catch (err) {
      setOutput(`[Sovereign Vault] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCheckpoint = async () => {
    if (!bootState.initialized || !bootState.agent) {
      setOutput("[Sovereign Vault] Error: Boot the system first")
      return
    }

    setIsLoading(true)
    setOutput(`[Sovereign Vault] Creating checkpoint and anchoring to Hedera...`)

    try {
      const response = await fetch("/api/checkpoint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentDid: bootState.agent,
          privateKey: bootState.privateKey,
          anchor: true, // Try to anchor to Hedera
        }),
      })

      const data = await response.json()

      if (data.error) {
        setOutput(`[Sovereign Vault] Error: ${data.error}`)
        return
      }

      let output = `[Sovereign Vault - CHECKPOINT CREATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VMO ID: ${data.checkpoint.vmo_id}
Checkpoint ID: ${data.checkpoint.payload.checkpoint_id}
VMO Count: ${data.vmo_count}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MERKLE ROOT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${data.merkle_root}

`

      if (data.hedera) {
        if (data.hedera.success) {
          output += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HEDERA ANCHOR - SUCCESS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Transaction ID: ${data.hedera.transaction_id}
Sequence Number: ${data.hedera.sequence_number}

This checkpoint is now immutably recorded on Hedera Hashgraph.
`
        } else {
          output += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HEDERA ANCHOR - PENDING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${data.hedera.error}

To anchor to Hedera, set environment variables:
- HEDERA_ACCOUNT_ID
- HEDERA_PRIVATE_KEY
- HEDERA_TOPIC_ID (optional, defaults to 0.0.7564883)
`
        }
      }

      output += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHECKPOINT VMO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${JSON.stringify(data.checkpoint, null, 2)}
`

      setOutput(output)
    } catch (err) {
      setOutput(`[Sovereign Vault] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleViewVMOs = async () => {
    setIsLoading(true)
    setOutput(`[Sovereign Vault] Fetching all VMOs with integrity verification...`)

    try {
      const response = await fetch("/api/vmo?verify=true")
      const data = await response.json()

      if (data.error) {
        setOutput(`[Sovereign Vault] Error: ${data.error}`)
        return
      }

      let output = `[Sovereign Vault - VMO REGISTRY]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Total VMOs: ${data.count}
Chain Integrity: ${data.chain_integrity?.valid ? 'VALID' : 'BROKEN'}
Verified: ${data.chain_integrity?.verified || 0}
${data.chain_integrity?.errors?.length > 0 ? `Errors: ${data.chain_integrity.errors.join(", ")}` : ""}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VMO LIST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

`
      for (const vmo of data.vmos) {
        output += `
[${vmo.vmo_id}]
  Type: ${vmo.type}
  Agent: ${vmo.provenance.agent_did}
  Time: ${vmo.provenance.timestamp}
  Hash: ${vmo.integrity.content_hash.slice(0, 32)}...
  Prev: ${vmo.integrity.prev_hash?.slice(0, 20) || "GENESIS"}...
`
      }

      setOutput(output)
    } catch (err) {
      setOutput(`[Sovereign Vault] Network error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAction = () => {
    switch (action) {
      case "boot":
        handleBoot(false)
        break
      case "createAgent":
        handleCreateAgent()
        break
      case "createCapability":
        handleCreateCapability()
        break
      case "checkpoint":
        handleCheckpoint()
        break
      case "viewVMOs":
        handleViewVMOs()
        break
    }
  }

  return (
    <div className="space-y-6">
      <div className="sovereign-card p-6">
        <h2 className="text-3xl font-bold mb-4 text-accent-blue">
          {"\u2B22"} Sovereign Vault
        </h2>
        <p className="text-muted-foreground mb-2">
          Verifiable Mutable Objects with cryptographic integrity and Hedera anchoring
        </p>
        
        {bootState.initialized ? (
          <div className="flex items-center gap-2 text-accent-green text-sm mb-6">
            <div className="w-2 h-2 rounded-full bg-accent-green pulse-glow" />
            <span>System Initialized - {bootState.stats?.totalVmos || 0} VMOs loaded</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-amber-500 text-sm mb-6">
            <div className="w-2 h-2 rounded-full bg-amber-500" />
            <span>Not Initialized - Boot required</span>
          </div>
        )}

        {/* Action Selection */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            className={`btn-gold py-2 px-3 rounded-lg text-sm ${action === "boot" ? "" : "btn-secondary"}`}
            onClick={() => setAction("boot")}
          >
            Boot System
          </button>
          <button
            className={`btn-gold py-2 px-3 rounded-lg text-sm ${action === "createAgent" ? "" : "btn-secondary"}`}
            onClick={() => setAction("createAgent")}
          >
            Create Agent
          </button>
          <button
            className={`btn-gold py-2 px-3 rounded-lg text-sm ${action === "createCapability" ? "" : "btn-secondary"}`}
            onClick={() => setAction("createCapability")}
          >
            Issue Capability
          </button>
          <button
            className={`btn-gold py-2 px-3 rounded-lg text-sm ${action === "checkpoint" ? "" : "btn-secondary"}`}
            onClick={() => setAction("checkpoint")}
          >
            Checkpoint
          </button>
          <button
            className={`btn-gold py-2 px-3 rounded-lg text-sm ${action === "viewVMOs" ? "" : "btn-secondary"}`}
            onClick={() => setAction("viewVMOs")}
          >
            View VMOs
          </button>
        </div>

        {/* Action-specific inputs */}
        {action === "boot" && (
          <div className="space-y-4 mb-4">
            <p className="text-sm text-muted-foreground">
              Boot from Hedera reads all messages from your HCS topic and reconstructs the sovereign timeline.
              Alternatively, start fresh for local testing.
            </p>
            <div className="flex gap-2">
              <button
                className="btn-gold flex-1 py-3 rounded-lg disabled:opacity-50"
                onClick={() => handleBoot(false)}
                disabled={isLoading}
              >
                {isLoading ? "Booting..." : "Boot from Hedera"}
              </button>
              <button
                className="btn-secondary flex-1 py-3 rounded-lg disabled:opacity-50"
                onClick={() => handleBoot(true)}
                disabled={isLoading}
              >
                Start Fresh (Local)
              </button>
            </div>
          </div>
        )}

        {action === "createAgent" && (
          <div className="space-y-4 mb-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-gold">Agent Name</label>
              <input
                type="text"
                value={agentName}
                onChange={(e) => setAgentName(e.target.value)}
                className="sovereign-input"
                placeholder="Agent name"
              />
            </div>
            <button
              className="btn-gold w-full py-3 rounded-lg disabled:opacity-50"
              onClick={handleCreateAgent}
              disabled={isLoading || !bootState.initialized}
            >
              {isLoading ? "Creating..." : "Create Agent VMO"}
            </button>
          </div>
        )}

        {action === "createCapability" && (
          <div className="space-y-4 mb-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-gold">Target Agent DID</label>
              <input
                type="text"
                value={capTarget}
                onChange={(e) => setCapTarget(e.target.value)}
                className="sovereign-input font-mono text-sm"
                placeholder="did:zpid:..."
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2 text-gold">Permissions (comma-separated)</label>
              <input
                type="text"
                value={capPermissions}
                onChange={(e) => setCapPermissions(e.target.value)}
                className="sovereign-input"
                placeholder="read, write, anchor"
              />
            </div>
            <button
              className="btn-gold w-full py-3 rounded-lg disabled:opacity-50"
              onClick={handleCreateCapability}
              disabled={isLoading || !bootState.initialized || !capTarget}
            >
              {isLoading ? "Issuing..." : "Issue Capability VMO"}
            </button>
          </div>
        )}

        {action === "checkpoint" && (
          <div className="space-y-4 mb-4">
            <p className="text-sm text-muted-foreground">
              Create a checkpoint VMO containing a Merkle root of all current VMOs.
              If Hedera credentials are configured, it will be anchored to HCS.
            </p>
            <button
              className="btn-gold w-full py-3 rounded-lg disabled:opacity-50"
              onClick={handleCheckpoint}
              disabled={isLoading || !bootState.initialized}
            >
              {isLoading ? "Creating..." : "Create Checkpoint & Anchor"}
            </button>
          </div>
        )}

        {action === "viewVMOs" && (
          <div className="space-y-4 mb-4">
            <p className="text-sm text-muted-foreground">
              View all VMOs in the current timeline with chain integrity verification.
            </p>
            <button
              className="btn-gold w-full py-3 rounded-lg disabled:opacity-50"
              onClick={handleViewVMOs}
              disabled={isLoading || !bootState.initialized}
            >
              {isLoading ? "Loading..." : "Fetch & Verify VMOs"}
            </button>
          </div>
        )}
      </div>

      {/* Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-gold">Cryptography</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- Ed25519 signatures</li>
            <li>- SHA-256 hashing</li>
            <li>- RFC 8785 JCS</li>
            <li>- Binary Merkle trees</li>
          </ul>
        </div>
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-blue">VMO Types</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- agent</li>
            <li>- capability</li>
            <li>- log</li>
            <li>- checkpoint</li>
            <li>- attestation</li>
          </ul>
        </div>
        <div className="sovereign-card p-4">
          <h4 className="font-semibold mb-3 text-accent-purple">Hedera Integration</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>- Boot from HCS topic</li>
            <li>- Anchor checkpoints</li>
            <li>- Immutable proofs</li>
            <li>- Mirror node reads</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
